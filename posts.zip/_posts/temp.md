```
public V put(K key, V value) {
    if (key == null)
        return putForNullKey(value);
    int hash = hash(key);
    int i = indexFor(hash, table.length);
    for (Entry<K,V> e = table[i]; e != null; e = e.next) {
        Object k;
        if (e.hash == hash && ((k = e.key) == key || key.equals(k))) {
            V oldValue = e.value;
            e.value = value;
            e.recordAccess(this);
            return oldValue;
        }
    }

    modCount++;
    addEntry(hash, key, value, i);
    return null;
}
```

hashset在放置新的成员之前会先进行比较，通过新成员和每个旧成员进行equals比较，来判断新成员是否和旧成员相同

而在AnnotationInvocationHandler中，invoke方法专门对equals函数进行了特殊处理

```
public Object invoke(Object var1, Method var2, Object[] var3) {
    String var4 = var2.getName();//var4就是调用的方法名
    Class[] var5 = var2.getParameterTypes();//var5就是传入方法的类型列表
    if (var4.equals("equals") && var5.length == 1 && var5[0] == Object.class) {//这里只要是equals并且使用了单对象就会进入
        return this.equalsImpl(var3[0]);
    } 
```