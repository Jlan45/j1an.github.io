---
title: URL和HTTP协议
abbrlink: 11f51f93
date: 2022-09-26 22:16:35
tags:
---

# URL

遇事不决先百度

> 因特网上的可用资源可以用简单字符串来表示，该文档就是描述了这种字符串的语法和语义。而这些字符串则被称为：“[统一资源定位器](https://baike.baidu.com/item/统一资源定位器/7682460?fromModule=lemma_inlink)”（URL）。这篇说明源于万维网全球信息主动组织（World Wide Web global informationinitiative）介绍的概念。RFC1630《通用资源标志符》描述了一些对象数据，他们自1990年起就开始使用这些对象数据。这篇URL说明符合《因特网资源定位符的功能需求（Functional Requirements for Internet Resource Locators）》中说明的需求。这篇文档是由工程任务组织（IETF）的URI工作小组写的 

肯定看不懂对吧，没关系，你只需要知道这个东西是用来寻找互联网上的资源就可以了，下面我们来看看一个URL的完整格式

```
scheme:[//[user[:password]@]host[:port]][/path][?query][#fragment]
```

贴心的中文翻译

```
协议:[//[用户[:密码]@]主机[:端口]][/路径][?队列][#片段]
```

下面我们以一个http协议的url来对上面的内容做一个解释

```
http://jlan.darkflow.top/posts/58958.html
```

我们来按照上面的语法来分析一下这个是什么内容

首先我们使用的是http协议来对jlan.darkflow.top这个服务主机进行访问，访问的是/posts/58958.html这个网页资源，这时候应该就会有人问了，为什么这个http的URL里面没有用户啊密码啊端口之类的东西呢，很简单，因为这些内容都是可选项，而http协议内容基本都是公开访问的，所以我们不需要指明我们用户的身份，并且http协议的默认端口是80端口，所以我们在访问这个URL的时候会自动的去80端口寻找资源

那如果我们没有把http服务放在80端口而是放在其他端口呢，来做个实验，我们用flask起一个web服务器，使用80端口作为http服务的端口![](https://jlan-blog.oss-cn-beijing.aliyuncs.com/202209262243049.png)

我们来直接访问看看，虽然我们没有在URL中添加端口，但是我们也成功访问到了我们的web站点，添加了80端口也是一样的，并且由于浏览器的特性，我们在添加80端口到URL中时默认是不会显示出来的

![](https://jlan-blog.oss-cn-beijing.aliyuncs.com/202209262245054.png)

下一步就是将默认端口进行更改，可以看到我们在代码中将端口更改为了10010，这时候我们再来直接访问看看

![](https://jlan-blog.oss-cn-beijing.aliyuncs.com/202209262243232.png)

可以看到我们现在用默认的80端口已经行不通了，那我们就加上我们自定义的端口号再来访问

![](https://jlan-blog.oss-cn-beijing.aliyuncs.com/202209262248667.png)

可以看到访问成功，并且在地址栏也出现了我们输入的自定义端口号

![](https://jlan-blog.oss-cn-beijing.aliyuncs.com/202209262251416.png)

那下一个我们可以来看一个ftp协议的URL

```
ftp://jlan@127.0.0.1/xxx/flag
```

这个就很明显了，我们以Jlan的身份在127.0.0.1服务器上面拿一份flag，可以看到我们也没有指定端口，因为ftp协议也是有默认端口的，其实几乎所有协议都会有一个默认的端口号，在一些使用这些协议的程序中大部分情况我们都不需要再额外添加端口

# HTTP

说完了URL我们来说另一个web的基础知识就是HTTP协议，同样先百度

> HTTP协议是Hyper Text Transfer Protocol（超文本传输协议）的缩写,是用于从万维网（WWW:World Wide Web ）服务器传输超文本到本地浏览器的传送协议。
>
> HTTP是一个基于TCP/IP通信协议来传递数据（HTML 文件, 图片文件, 查询结果等）。
>
> HTTP是一个属于应用层的面向对象的协议，由于其简捷、快速的方式，适用于分布式超媒体信息系统。它于1990年提出，经过几年的使用与发展，得到不断地完善和扩展。目前在WWW中使用的是HTTP/1.0的第六版，HTTP/1.1的规范化工作正在进行之中，而且HTTP-NG(Next Generation of HTTP)的建议已经提出。
>
> HTTP协议工作于客户端-服务端架构为上。浏览器作为HTTP客户端通过URL向HTTP服务端即WEB服务器发送所有请求。Web服务器根据接收到的请求后，向客户端发送响应信息。

![img](https://upload-images.jianshu.io/upload_images/2964446-fdfb1a8fce8de946.png?imageMogr2/auto-orient/strip%7CimageView2/2)

上面这张图就很好的说明了HTTP协议定义的内容

啊反正HTTP协议就是一种传输网页内容的协议，协议就是双方定义了一种数据交换的方式，按照规定的格式来传输数据，web手所谓的“抓包”就是对HTTP的数据包进行拦截，然后取出其中的原始数据，多说无益，我们来实际抓包尝试一下，还是使用刚才的web服务器

![](https://jlan-blog.oss-cn-beijing.aliyuncs.com/202209262325345.png)

看这里就是一整个完整的请求和响应内容了，第一行是请求的方法和协议，后面每行都是一个请求标头，最后有一个回车和换行结束，这是一个完整的GET请求，那POST类型的请求是什么样子的呢，我们再来看一下

![](https://jlan-blog.oss-cn-beijing.aliyuncs.com/202209262335979.png)

发现请求的最下面是我们传入的内容，并且又多了一个叫做Content-Length的请求头，这个请求头就是告诉服务器，我们在最后一个换行之后还有9字节的内容需要传输，我们试试在服务器中将内容取出并且回显，那如果我们修改这个请求头让它比我们实际的请求短会发生什么呢

![](https://jlan-blog.oss-cn-beijing.aliyuncs.com/202209262336473.png)

可以看到服务器按照我们的请求头声明的一样，只取了前8位的内容，返回了jla





 















