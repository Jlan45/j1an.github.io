---
title: JNDI安全详解
tags:
  - Java
abbrlink: 6ce81c59
date: 2022-11-29 19:36:24
---

# JNDI

## 简介

> JNDI（ Java Naming and Directory Interface***#Java命名和目录接口***）是一种Java API，类似于一个索引中心，它允许客户端通过name发现和查找数据和对象。这些对象可以存储在不同的命名或目录服务中，例如远程方法调用（RMI），通用对象请求代理体系结构（CORBA），轻型目录访问协议（LDAP）或域名服务（DNS）
>
> **Naming Service**：命名服务是将名称与值相关联的实体，称为"绑定"。它提供了一种使用"find"或"search"操作来根据名称查找对象的便捷方式。 就像DNS一样，通过命名服务器提供服务，大部分的J2EE服务器都含有命名服务器 。
>
> **Directory Service**：是一种特殊的Naming Service，它允许存储和搜索"目录对象"，一个目录对象不同于一个通用对象，目录对象可以与属性关联，因此，目录服务提供了对象属性进行操作功能的扩展。一个目录是由相关联的目录对象组成的系统，一个目录类似于数据库，不过它们通常以类似树的分层结构进行组织。可以简单理解成它是一种简化的RDBMS系统，通过目录具有的属性保存一些简单的信息。

关于JNDI和这些服务的关系具体可以看这个图

![](https://image.3001.net/images/20220214/1644818999_6209f237022d14165a1e9.png!small?1644818997380)

我们可以理解为JNDI是一种上层的规范，而下面的服务都是对这个规范的一个具体实现

个人理解就是Naming Service提供的服务就是将一个对象和一个url进行绑定，而具体如何实现对某个对象的加载是又下层的RMI等具体服务来执行的

就比如同样获取一个文件，我们既可以选择http服务也可以选择ftp服务，但是他们都是通过TCP/IP协议传输的

其中JDK默认内置了如下SPI：

- Lightweight Directory Access Protocol (LDAP)
- Common Object Request Broker Architecture (CORBA) Common Object Services (COS) name service
- Java Remote Method Invocation (RMI) Registry
- Domain Name Service (DNS)

同时JNDI分为了5个包：

- [javax.naming](https://docs.oracle.com/javase/tutorial/jndi/overview/naming.html)
- [javax.naming.directory](https://docs.oracle.com/javase/tutorial/jndi/overview/dir.html)
- [javax.naming.ldap](https://docs.oracle.com/javase/tutorial/jndi/overview/dir.html)
- [javax.naming.event](https://docs.oracle.com/javase/tutorial/jndi/overview/event.html)
- [javax.naming.spi](https://docs.oracle.com/javase/tutorial/jndi/overview/event.html)

例如上面说到的RMI Registry就是使用的Naming Service。其应用场景比如：动态加载数据库配置文件，从而保持数据库代码不变动等。
代码格式如下：

```java
String jndiName= ...;//指定需要查找name名称
Context context = new InitialContext();//初始化默认环境
DataSource ds = (DataSourse)context.lookup(jndiName);//查找该name的数据
```



















部分内容引用：

https://paper.seebug.org/1091/#jndi







