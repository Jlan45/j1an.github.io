---
title: Java入门
abbrlink: 63f03572
date: 2022-06-09 00:12:01
tags:
---

# JAVA

**Hello World!**

```java
//Main.java
public class Main {
    public static void main(String[] args) {
        System.out.println("Hello world!");
    }
}
//javac Main.java
//java Main
//JDK 11以后支持直接使用java执行源代码
```

**JDK（Java开发工具包）组成**

- JVM：Java虚拟机，java程序运行的地方
- 核心类库：Java自带类，供程序员调用
- JRE：Java运行环境

**数据类型**

基本数据类型

- 整数
  - byte    1字节
  - short    2字节
  - int（默认）    4字节
  - long    8字节（整数定义时需要在数字末尾加L）
- 浮点数
  - float    4字节（定义时需要在数字末尾加F）
  - double（默认）    8字节
- 字符：char 2字节
- 布尔：boolen

引用数据类型











**类型转换**

默认类型转换，小的自动换成大的

```java
byte a=1;
byte b=1;
byte c=a+b;//此处程序报错，因为ab在进行加运算前已经执行被转换成int类型
int c=a+b;//此处正确
```

**运算符**

和C++一样，字符串的优先级拉满

**Java原生API**

[官方文档](https://www.oracle.com/java/technologies/javase-jdk17-doc-downloads.html)

**Java用户输入（练习系统API使用）**

```java
import java.util.Scanner;//导入Scanner包
public class scannerDemo {
    public static void main(String[] args) {
        Scanner s=new Scanner(System.in);//创建一个Scanner对象
        System.out.print("请输入您的年龄：");
        int age=s.nextInt();//获取Scanner得到的内容
        System.out.println("您的年龄是："+age);
    }
}
```

**程序流程控制**

if，switch，for，while和C++完全一致

**Random包**

```java
import java.util.Random;
public class randomDemo {
    public static void main(String[] args) {
        Random r=new Random();
        int shu=r.nextInt(10);//0-9范围
    }
}
```

**数组**

```java
//静态初始化数组
int[] arr={20,10,234,22,15};
String[] name={"PSR","ZYL","HZJ"}
//动态初始化数组
int [] arr=new int[10]
```

动态初始化数组默认值：

整型：0

浮点型：0.0

布尔：false

引用类型：null

**方法（就函数啦）**

完整定义格式：

```
修饰符 返回值类型 方法名(形参){
    方法体代码
    return 返回值;
}
```

```java
public static int sum(int a,int b){
    int c=a+b;
    System.out.println("您求的和为："+c);
    return c;
}
```

其他定义格式：

可以没有返回值（void），没有参数

**方法数据传递机制**

基本类型参数传递：传值

引用类型参数传递：传地址

**方法重载**

方法名一样参数不一样的方法

**类**

```java
package top.darkflow.OP;
public class Phone{
    String brand;
    double price;
    public void start(){
        System.out.println("欢迎使用"+brand+"手机");
    }
}
//构造器写法与C++相同
//this关键在代表当前对象的地址
```

**JavaBean**

也被称作实体类，其对象可用于在程序中封装数据

要求：

- 成员变量用private修饰
- 提供对应成员变量的get与set方法
- 必须有一个无参构造器，有参构造可有可无

**String类**

不可变：指原始字符串不可变，经过+运算后产生新的字符串

创建方式

```
String s=new String("flag");
char[] chars={'f','l','a','g'};
String s=new String(chars);
byte[] bytes={102,108,97,103}
String s=new String(bytes);
```

**String常用API**

```
s1.equals(s2)//比较s1，s2字符串内容是否相同equalsIgnoreCase忽略大小写
s1.charAt(Index)//获取Index位置的字符
s1.toCharArray()//将字符串转换为char数组
s1.substring(head,end)//截取字符串
s1.replace(target,replacement)//将字符串中的target用replacement替换
s1.contains(s)//字符串中是否包含s字符串
s1.startWiths(s)//字符串是否以s字符串开始
s1.spilt(s)//以s为分割符来将字符串切割
```

**ArrayList**

```
ArrayList list=new ArrayList()
list.add(ele)//向列表中添加元素（无类型限制）
list.add(index,ele)//向列表指定位置插入元素
```

ArrayList支持泛型，可通过`ArrayList<数据类型>`来限定列表中的数据类型

一些API

```
list.get(index)//获取指定位置元素
list.size()//获取列表元素个数
list.remove(index)//删除指定位置的元素
list.set(index,ele)//修改指定位置的元素
```

### 面向对象咯

**static关键字**

- static是静态的意思，可以用来修饰成员变量和成员方法
- static修饰成员变量表示该成员变量值在内存中储存一份，可以被共享访问修改
- 静态成员变量常用来表示需要被共享的信息，可以被共享访问
- 静态成员变量和方法访问时可通过`类名.成员`也可通过`对象名.成员`访问，建议通过类访问
- 在同一个类中，访问静态方法，类名可以省略不写
- 注意调用静态成员方法（包括通过对象调用），方法中不能调用非静态成员变量哦（如下图）
- ![](https://jlan-blog.oss-cn-beijing.aliyuncs.com/202207050029328.png)
- 静态方法中不可以出现this关键字

**静态方法应用**

- 可用于构造工具类，由于不需要进行实例化，可将类的构造函数设置成私有权限

**代码块**

定义：花括号括起来的都是代码块

- static代码块（static{}）：
  - 属于类，与类一起优先加载（比main还快）一次，自动触发执行
  - 作用：可以用于初始化静态资源，一边后续使用
- 实例代码块（{}）：
  - 属于对象，每次构建对象时，都会出发一次执行
  - 作用：初始化实例资源

**设计模式**：在开发中经常遇到的问题的最优解

**单例模式**

一个类只能创建一个对象

```java
//饿汉单例，在类加载时直接创造对象
public class danli {
    public static danli dddd=new danli();
    private danli(){
        System.out.println("单例被创建");
    }
}
//懒汉单例，在类实例首次被调用时创造对象
public class danli {
    public static danli dddd;
    private danli(){
        System.out.println("单例被创建");
    }
    public static danli getInstance(){
        if(dddd==null){
            dddd=new danli();
        }
        return dddd;
    }
}
```

**继承**

- ```
  public class Son extends Father {}
  ```

- super关键字

  - `super`可以用来引用直接父类的实例变量。
  - `super`可以用来调用直接父类方法。
  - `super()`可以用于调用直接父类构造函数。

- 构造方法：默认先执行父类无参构造，再执行自己构造

**包**

- 包是用来分别管理各种不同的类的，类似文件夹，建包有利于程序的管理和维护
- 包名语法格式：域名倒写.技术名称
- 建包语句必须在第一行
- 相同包下的类可直接访问，不同包下类必须导包，`import 包名.类名`
- 如果该类中使用不同包下相同的类名，此时默认只能导入一个类的包，另一个类的要使用全名访问

**权限修饰符**

- 私有：`private`
  - 只能在本类中访问
- 缺省：啥都不加
  - 只能本类，本包下访问
- 保护：`protected`
  - 本类，同包的其他类中，其他包的子类中
- 公共：`public`
  - 谁都能访问

**final关键字**

- 修饰类：表明最终类，不可被继承
- 修饰方法：表明最终方法，不可被重写
- 修饰变量：表明变量经过首次赋值后，不能再次被赋值
- 常量定义：`public static final`

**枚举**

- 作用：为了做信息的标志和信息的分类

- ```java
  修饰符 enum 枚举名称{
  	第一行都是罗列枚举类实例的名称
  }
  ```

- 枚举都继承自枚举类型：`java.lang.Enum`

- 枚举类都是最终类

- 构造器的构造器都是私有的，枚举对外不能创建对象

- 枚举类的第一行默认都是罗列枚举对象的名称的

- 枚举类相当于是多例模式

- ```java
  //枚举类的作用实例代码
  //例如开发游戏接受用户输入的四个方向的信号
  //如果选择常量，具有可读性但是入参值不受约束
  //Orientation.java
  public enum Orientation {
      UP,DOWN,LEFT,RIGHT
  }
  //zhu.java
  public class zhu {
      public static void move(Orientation o){
          switch (o){
              case UP -> System.out.println("往上走");
              case DOWN ->System.out.println("往下走");
              case LEFT -> System.out.println("往左走");
              case RIGHT -> System.out.println("往右走");
          }
      }
      public static void main(String[] args) {
          move(Orientation.RIGHT);
      }
  }
  ```

- ![](https://jlan-blog.oss-cn-beijing.aliyuncs.com/202207061509169.png)

**抽象**

- abstract修饰的类就是抽象类，修饰的方法就是抽象方法

- 写抽象方法时不能写方法体

- 如果一个类中的方法被声明成为抽象方法，那么这个类必须被声明为抽象类

- ```java
  public abstract class animal {
      public abstract void run();
  }
  ```

- 抽象类可以理解为不完整的设计图，一般做父类

- 当父类知道子类需要完成某些行为，而各个子类实现方法又不同，就把该类定义为抽象方法

**接口**

- ```java
  //接口定义
  public interface 接口名{
  		//常量
  		//抽象方法
  }
  ```

- ```java
  //接口实现
  class 类名 implements 接口1,接口2...{
  		//抽象方法重写
  }
  ```

- 接口可以多继承，一个接口可以继承多个接口

- 接口不能创建对象

- 一个类实现多个接口，多个接口中有同样的静态方法不冲突

- 一个类继承了父类又实现了接口，父类和接口中的同名方法，默认使用父类的

- 一个类实现了多个接口，多个接口中存在同名的默认方法，不冲突，这个类重写该方法即可

- 一个接口继承多个接口是没有问题的，如果多个接口中存在规范冲突则不能继承

- JDK8开始对接口做的新增方法

  - 接口中可以有带方法实现的方法
  - 默认方法：类似之前的普通方法，使用defalut修饰，默认用public修饰。需要用接口实现类的对象来调用
  - 静态方法：使用static修饰，接口静态方法必须用本身的接口名来调用
  - 私有方法：使用private修饰，只能在本类（本接口）中被其他的默认方法或者私有方法访问
