---
title: Python基础
tags:
  - Python
abbrlink: 14702
date: 2022-01-11 00:50:50
---

# Python基础

#### 数据类型：

string（字符串）

num（数字）

bool（布尔）

list（列表）使用[    ]定义

tuple（元组）使用{     }定义（无序）

dictionary（字典）使用{     }定义，内容为：下标名:元素内容

<!--more-->

#### 字符串相关函数：

###### 查找：

```python
str.find(str1,start,end)//rfind从末尾开始查找
str.index(str1,start,end)//rindex从末尾开始查找
```

在字符串中查找是否存在str1，存在返回第一次出现的位置，不存在find返回-1，index报错

```python
str.count(str1,start,end)
```

查找字符串中某字符串出现的次数

###### 替换：

```python
str.replace(old,new,count)
```

将字符串中old内容替换为new，count为最大替换次数，返回新字符串，不改变原来字符串

###### 切割：

```python
str.split(str1,count)
```

将字符串以str1为分隔切割，count为最大切割次数，返回一个列表，不改变原有字符串，默认按空白字符进行全切割

###### 加入：

```python
str.join(可迭代对象)
```

将str插入到可迭代对象两个元素之间，返回一个字符串

###### 乱七八糟：

```python
capitalize(str)//将字符串中第一个字母大写
title(str)//字符串中每个单词首字母大写
str.startwith(str1)//检查字符串是否以str1开头
str.endwith(str1)//检查字符串是否以str1结尾
str.upper()//字母全大写
str.lower()//字母全小写
```





input输入

print输出

read读文件（按字节读），readline（按行读）

open("文件名"，"打开方式（r只读，w写入，a追加，（b）代表以二进制打开，（+）代表读写）"，encoding="编码方式")打开文件（以二进制进行读写时不能指定encoding方式）

*args不定长参数，接收后生成元组

**kwargs不定长参数，接收后生成字典

#### Python内存管理机制：引用计数

```python
a=1 #a地址引用为1
b=a #a地址引用为2
del a #a地址引用为1
del b #a地址引用为0，此时a引用地址被销毁
```

