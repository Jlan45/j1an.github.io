---
title: Windows内网域渗透3
abbrlink: d114db98
date: 2022-10-19 19:22:18
tags:
---

# 低权限搜集本机密码文件

- **dir命令搜集当前机器各类密码配置文件**

  一般配置或密码文件都是：

  ```
  pass.*,config.*,username.*,password.*
  ```

  可以直接使用dir命令进行搜集，建议不要从C盘扫，从user目录下扫描

  ```cmd
  dir /b /s user.*,pass.*,config.*,username.*,password.*
  ```

  我们cd到目标目录后直接执行，发现密码文件：

  ![](https://jlan-blog.oss-cn-beijing.aliyuncs.com/202210192105452.png)

  我们直接查看

  ![](https://jlan-blog.oss-cn-beijing.aliyuncs.com/202210192107139.png)

- **for循环搜集当前机器各类敏感密码的配置文件**

  ```cmd
  for /r C:\ %i in (pass.*) do @echo %i
  ```

  这个耗时比较久，我们需要稍等再查看，最终结果和上面的dir命令是相似的

- **findstr命令查找文件中的字段**

  ```cmd 
  findstr /c:"user" /c:"pass" /si *.txt
  ```

  ![](https://jlan-blog.oss-cn-beijing.aliyuncs.com/202210192112055.png)







