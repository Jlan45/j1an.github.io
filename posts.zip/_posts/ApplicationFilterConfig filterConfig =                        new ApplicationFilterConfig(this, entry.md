---
abbrlink: '0'
---
```
                ApplicationFilterConfig filterConfig =
                        new ApplicationFilterConfig(this, entry.getValue());//这里的value是一个filterDef，这么看来config是在初始化的时候动态生成的
                filterConfigs.put(name, filterConfig);//将filter放入filterConfigs中
这两句后面应该用的上
```

```
                fireLifecycleEvent(Lifecycle.CONFIGURE_START_EVENT, null);
        for (FilterMap filterMap : webxml.getFilterMappings()) {
            context.addFilterMap(filterMap);
        }
        通过一个for循环把注解和web.xml里面的数据都拿出来
从这里开始加的filtermap
filterMaps.add(filterMap);最后就这一句nnd

```

![](https://jlan-blog.oss-cn-beijing.aliyuncs.com/202301181724518.png)

filtermap要长成这样

![](https://jlan-blog.oss-cn-beijing.aliyuncs.com/202301181728936.png)

```
public void addFilterMap(FilterMap filterMap) {
    validateFilterMap(filterMap);
    // Add this filter mapping to our registered set
    filterMaps.add(filterMap);
    fireContainerEvent("addFilterMap", filterMap);
}
```