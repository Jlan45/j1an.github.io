---
title: Windows内网域渗透
tags:
  - 内网渗透
abbrlink: a0d619b1
date: 2022-10-12 20:41:04
---

# Windows内网域渗透

## 域森林下的内网信息搜集

在我们进行渗透测试进入内网后，面对的是一片黑暗，所以我们首先应当做的就是对当前所处的网络环境进行一个判断，通常分为三种判断

- 我是谁————对机器角色判断
- 这是哪————对目前机器所处的网络环境的拓扑结构进行分析和判断
- 我在哪————对目前机器所处的位置区域进行判断

所以我们需要对目标内网进行信息搜集，搜集的越多对内网越了解才能在渗透中如鱼得水

那假设我们现在已经获取到**darkflow.com**域中的**web-2021**机器的控制权限，接下来我们尝试使用CS来进行内网信息搜集

### 是否在域中

在对Windows进行内网渗透的时候，针对域环境和工作组环境所进行的渗透方式是完全不同的，所以我们应当先判断主机事都在域中，此处有两种方式

1. 使用`ipconfig /all`查看当前网卡和IP信息

   ![](https://jlan-blog.oss-cn-beijing.aliyuncs.com/202210122203724.png)

   可以看到命令执行之后在IP配置汇总存在主DNS后缀，这代表我们存在在域环境中，反之则是工作组环境

2. 使用`systeminfo`查看系统详细信息

   ![](https://jlan-blog.oss-cn-beijing.aliyuncs.com/202210122205249.png)

   此处中域显示为一个域名，而如果是工作组则会显示WORKGROUP

3. 使用`net config workstation`查看当前登录域以及用户

   ![](https://jlan-blog.oss-cn-beijing.aliyuncs.com/202210132335431.png)

   可以看到其中有工作站域并且不是WORKGROUP

4. 使用`net time /domain`来查看系统时间，其中的`/domain`参数代表其只能在域环境中执行

   该命令执行后有三种情况

   - 存在域但当前用户并非域内用户：`发生系统错误，拒绝访问`
   - 存在域并且当前用户是域内用户：显示域以及时间
   - 不存在域：找不到WORKGROUP的域控制器

### 本机信息搜集

在分辨好我们是在域中还是工作组后，我们就可以对当前机器进行信息搜集了

- **获取本机网络配置信息**：`ipconfig /all`

  ![](https://jlan-blog.oss-cn-beijing.aliyuncs.com/202210132346666.png)

  用来分析网络拓扑，如果机器在内网中我们就可以扩大范围进行内网的横向渗透，拿下更多资产

- **查询操作系统和版本信息**：`systeminfo | findstr /B /C:"OS"`

  ![](https://jlan-blog.oss-cn-beijing.aliyuncs.com/202210132345103.png)

  可以了解到本机的系统版本，在我们想要进行提权的时候我们可以针对性的寻找对应的exp

- **查看本机已安装的软件及版本，路径**：`wmic product get name,version`

  ![](https://jlan-blog.oss-cn-beijing.aliyuncs.com/202210140055450.png)

  通过搜集已安装的软件信息，可以针对某款软件的漏洞来进行一些提权等操作

- **查看本机进程信息**：`tasklist /v`

  ![](https://jlan-blog.oss-cn-beijing.aliyuncs.com/202210140100985.png)

  通过该命令查询的系统进程信息可显示出进程的运行用户（SYSTEM用户权限以下）及目录，在后期我们可以通过令牌窃取来进行提取

- **杀毒软件进程查看**：`tasklist /SVC`

  ![](https://jlan-blog.oss-cn-beijing.aliyuncs.com/202210141410006.png)

  将该命令的返回值提交对应的[查询网站](https://www.adminxe.com/CompareAV/index.php)即可查看是否有杀毒软件，方便我们与杀软对抗

- **启动程序信息**：`wmic startup get command,caption`

  ![](https://jlan-blog.oss-cn-beijing.aliyuncs.com/202210141421601.png)

  可以看到详细的启动项命令及描述

- **查看计划任务**：`schtasks /query /fo LIST /v`

  ![](https://jlan-blog.oss-cn-beijing.aliyuncs.com/202210141535865.png)

  通过查看本机计划任务可以利用定时任务来做定时任务劫持

- **查看主机开机时间**：`net statistics workstation`

  ![](https://jlan-blog.oss-cn-beijing.aliyuncs.com/202210141538799.png)

  可以通过查看开机时间来判断是否经常有人管理使用这台机器

- **查看用户**：`net user` `net user 执行用户`

  ![](https://jlan-blog.oss-cn-beijing.aliyuncs.com/202210141602726.png)

  ![](https://jlan-blog.oss-cn-beijing.aliyuncs.com/202210141604248.png)

  没啥好说的，就是查看用户，还可以查看指定用户属于的组

- **查看当前在线用户**：`query user || qwinsta`

  ![](https://jlan-blog.oss-cn-beijing.aliyuncs.com/202210141610279.png)

  通过查看当前在线用户可以知道管理员是否在登录，如果我们RDP登录到远程桌面然后撞上管理员就不好了

- **查看本机端口开放情况**：`netstat -ano`

  ![](https://jlan-blog.oss-cn-beijing.aliyuncs.com/202210141614976.png)

  可以查看本机是否与其他机器产生连接，分析本机开启的业务

- **查询补丁信息**：`systeminfo` `wmic qfe get Caption,Description,HotFixID,InstalledOn`

  ![](https://jlan-blog.oss-cn-beijing.aliyuncs.com/202210141616251.png)![](https://jlan-blog.oss-cn-beijing.aliyuncs.com/202210141618610.png)

  看看漏洞是否被修复，针对性寻找exp

- **查询路由表**：`route print`

  ![](https://jlan-blog.oss-cn-beijing.aliyuncs.com/202210141622076.png)

  **所有可用接口的ARP缓冲表**：`arp -a`

  ![](https://jlan-blog.oss-cn-beijing.aliyuncs.com/202210141633543.png)

  通过分析路由可以知道机器可以访问哪些网段的资源

- **查看防火墙设置**：`netsh firewall show config`

  ![](https://jlan-blog.oss-cn-beijing.aliyuncs.com/202210141635082.png)

  查看防火墙的开关情况，以及相关的配置信息

  如果我们相对防火墙相关内容进行一些更改可以使用下面的命令

  ```powershell
  在Windows 2003及之前版本，使指定程序全部连接：
  netsh firewall add allowedprogram 程序路径 "规则名" enable
  
  在Windows 2003之后的版本，使用以下命令：
  netsh advfirewall firewall add rule name="规则名" dir=in action=allow program="程序路径"
  
  允许指定程序连出：
  netsh advfirewall firewall add rule name="规则名" dir=out action=allow program="程序路径"
  
  允许指定端口放行：
  netsh advfirewall firewall add rule name="规则名" protocol=TCP dir=in localport=端口 action=allow program="程序路径"
  
  自定义防火墙日志存储位置：
  netsh advfirewall set currentprofile logging filename "存储文件路径"
  
  Windows 2003及之前版本关闭防火墙：
  netsh firewall set opmode disable
  
  Windows 2003以后版本关闭防火墙：
  netsh advfirewall set allprofiles state off
  ```

- **查询并开启远程桌面服务**：`REG QUERY "HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Control\Terminal Server\WinStations\RDP-Tcp" /V PortNumber`

  ![](https://jlan-blog.oss-cn-beijing.aliyuncs.com/202210141652896.png)

  开启远程桌面的命令
  
  ```powershell
  Windows Server 2003开3389端口
  wmic path win32_terminalservicesetting where (_CLASS !="") call setallowtsconnections 1
  
  Windows Server 2008 和 Windows Server 2012开3389端口
  wmic /namespace:\\root\cimv2\terminalservices path win32_terminalservicesetting where (_CLASS !="") call setallowtsconnections 1
  或
  wmic /namespace:\\root\cimv2\terminalservices path win32_tsgeneralsetting where (TerminalName='RDP-Tcp') call setuserauthenticationrequired 1
  
  Windows 7开3389端口
  reg add "HKLM\SYSTEM\CURRENT\CONTROLSET\CONTROL\TERMINAL SERVER" /v fSingleSessionPerUser /t REG DWORD /d 0 /f
  ```

### 域内信息搜集

- **获取域SID**：`whoami /all`

  ![](https://jlan-blog.oss-cn-beijing.aliyuncs.com/202210151703166.png)

  搜集SID可以用于票据传递攻击，还有部分提权方式需要手机特权信息来进行

- **查询域内容户**：`net user /domain`

  ![](https://jlan-blog.oss-cn-beijing.aliyuncs.com/202210151706114.png)

- **查看域内用户详细信息**：`net user 用户名 /domain`

  ![](https://jlan-blog.oss-cn-beijing.aliyuncs.com/202210151707950.png)

  可以看到组成员内容来判断用户组及权限

- **查看本机所在的所有域**：`net view /domain`

  在存在多个域的时候可以使用这个命令来看所存在的所有域
  
- **查询域管理员列表**：`net group "domain admins" /domain`

  ![](https://jlan-blog.oss-cn-beijing.aliyuncs.com/202210161722867.png)

  可以看到只有一个域管理员

- **查看域内时间（时间服务器）**：`net time /domain`

  ![](https://jlan-blog.oss-cn-beijing.aliyuncs.com/202210161724650.png)

  通过查看域内时间以及时间服务器，就可以使用定时任务+IPC来运行一些bat文件，并且可以通过ping域内时间服务器来得到其IP

  ![](https://jlan-blog.oss-cn-beijing.aliyuncs.com/202210161728786.png)

- **查看登录本机的域管理员**：`net localgroup administrators /domain`

  ![](https://jlan-blog.oss-cn-beijing.aliyuncs.com/202210161730087.png)

- **查看域中所有用户组**：`net groups /domain`

  ![](https://jlan-blog.oss-cn-beijing.aliyuncs.com/202210161731765.png)

- **查看主域控制器**：`netdom query pdc`

  ![](https://jlan-blog.oss-cn-beijing.aliyuncs.com/202210161732635.png)

  直接ping就能拿到IP

- **查看所有域控制器**：`net group "Domain Controllers" /domain`

  ![](https://jlan-blog.oss-cn-beijing.aliyuncs.com/202210161734364.png)
  
  这里应该还有个辅域的，但是不知道为啥消失了，后面再回来看看
  
  这里我们可以通过域控制器的机器名称来查看域控主机，知道其IP后我们可以对其进行针对性的渗透，只需渗透核心机器，整个域的控制权也就到手了
  
- **查询域信任信息**：`nltest /domain_trusts`

  ![](https://jlan-blog.oss-cn-beijing.aliyuncs.com/202210170338052.png)

  可以看到主域名是bxsteam.com，并且有一个saul子域，二者双向认证，彼此的用户可以互相登录

- **查询域密码信息**：`net accounts /domain`

  ![](https://jlan-blog.oss-cn-beijing.aliyuncs.com/202210170340232.png)

  可以看到域中密码使用策略，在爆破时防止我们生成无效的密码字典

