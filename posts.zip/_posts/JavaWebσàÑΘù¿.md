---
title: JavaWeb入门
abbrlink: 84f639f6
date: 2022-07-08 01:28:23
tags:
 - Java
---

# JavaWeb

### JDBC API

快速入门

1. 创建工程导入驱动jar包
2. 注册驱动`Class.forName("com.mysql.jdbc.Driver");`
3. 获取链接`Connection conn= DriverManager.getConnection(url,username,password);`
4. 准备sql语句`String sql="update nnn set id=5 where id=4";`
5. 获取执行sql对象Statement`Statement stmt=conn.createStatement();`
6. 执行sql并获取返回内容`int count=stmt.executeUpdate(sql);`
7. 关闭链接`stmt.close();conn.close();`

### API详解

##### DriverManager

- 驱动管理类的作用
  - 注册驱动
  - 获取数据库的连接
- 一些方法（都是静态方法）
  - `getConnection()`尝试建立与给定数据库URL的连接
    - url：jdbc:数据库类型://IP:端口/数据库名称?参数
  - `registerDriver()`注册给定的驱动程序，上面mysql中的Driver类本质利用的还是这个函数

##### Connection

- 数据库连接对象的作用

  - 获取执行SQL的对象
  - 管理事务

- 一些方法

  - `Statement createStatement()`普通执行SQL对象
  - `PreparedStatement preparedStatement(sql)`预编译SQL的执行SQL对象，防SQL注入
    - 首先获取一个PreparedStatement对象，然后SQL语句中的参数值用?代替占位
    - 进行`setxxx(参数1,参数2)`来给?赋值
    - 直接执行无需再次穿参

  - MySQL事务管理
  - `setAutoCommit(boolen)`true为自动提交事务，false为手动提交事务，即为开启事务
  - `commit()`提交事务
  - `rollback()`回滚事务

##### Statement

- 作用：执行SQL语句
- `int executeUpdate(sql)`执行DML，DDL语句，返回DML语句影响的行数，DDL语句执行后，执行成功也可能返回0
- `ResultSet executeQuery(sql)`执行DQL语句，返回结果集对象
- ResultSet
  - `next()`光标向后移一位并判断是否有内容
  - `gets数据类型(列名或列数)`获取当前光标指向的内容

##### 数据库连接池

- 为了保持数据库连接存在

- 使用过程

  1. 导入jar包

  2. 定义配置文件，示例如下

     ```
     driverClassName=com.mysql.jc.jdbc.Driver
     url=jdbc:mysql://127.0.0.1:3306/db1?characterEncoding=utf-8
     username=root
     password=123456
     initialSize=5
     maxActive=10
     maxWait=5000
     ```

  3. 导入配置文件`Properties prop=new Properties();`

     `prop.load(new FileInputStream("/Users/jlan/IdeaProjects/JavaWeb/jdbc-demo/src/druid.properties"));`

  4. 建立连接`DataSource dataSource= DruidDataSourceFactory.createDataSource(prop);`
     `Connection connection=dataSource.getConnection();`

##### Maven

- Maven是专门用于管理和构建Java项目的攻击，它的主要功能有

  - 提供了一套标准化的项目结构

    - maven-project——项目名称
      - src——源代码和测试代码目录
        - main——源代码目录
          - java——源代码Java文件目录
          - resources——源代码配置文件目录
          - webapp——web项目核心目录
        - test——测试代码目录
          - java——测试代码Java文件目录
          - resources——测试代码配置文件目录
        - pom.xml——项目核心配置文件

  - 提供了一套标准化的构建流程

    - 正常构建流程
      - 编译，测试，打包，发布
    - Maven提供一套命令来简单构建

  - 提供了一套依赖管理机制

    - 正常导入包流程

      - 下载jar包
      - 复制jar包到项目
      - 导入jar包

    - Maven导入包

      - 更改pom.xml配置文件即可 

        ```
        
        ```

        

- 使用Maven构建的项目结构完全一样，所有IDE创建的Maven项目可以通用

- Maven的仓库

  - 本地仓库：本地计算机上的一个目录
  - 中央仓库：由Maven团队维护的全球唯一的仓库
  - 远程仓库：一般是由公司搭建的私有仓库

##### MyBatis

- 是一款持久层（负责将数据保存到数据库的那一层代码）框架，用于简化JDBC开发
- JDBC的缺点：硬编码，操作繁琐
- MyBatis通过配置文件解决了硬编码和操作繁琐的问题，通过预先定义的配置文件来简化连接及处理结果集的工作

##### Servlet

- 第一个示例程序

- ```java
  //MyFirstServlet.java
  package top.darkflow;
  import javax.servlet.*;
  import java.io.IOException;
  import java.io.PrintWriter;
  public class MyFirstServlet implements Servlet {
      public void init(ServletConfig config) throws ServletException {
          System.out.println("Init");
      }
      public void service(ServletRequest request, ServletResponse response)
              throws ServletException, IOException {
          System.out.println("From service");
          PrintWriter out = response.getWriter();
          out.println("Hello, Java Web.");
      }
      public void destroy() {
          System.out.println("Destroy");
      }
      public String getServletInfo() {
          return null;
      }
      public ServletConfig getServletConfig() {
          return null;
      }
  }
  ```

- ```xml
  <!--web.xml-->
  <?xml version="1.0" encoding="UTF-8"?>
  <web-app version="2.4" xmlns="http://java.sun.com/xml/ns/j2ee"
           xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
           xsi:schemaLocation="http://java.sun.com/xml/ns/j2ee
  http://java.sun.com/xml/ns/j2ee/web-app_2_4.xsd">
      <servlet>
          <servlet-name>MyFirstServletName</servlet-name>
          <servlet-class>com.skyline.MyFirstServlet</servlet-class>
      </servlet>
      <servlet-mapping>
          <servlet-name>MyFirstServletName</servlet-name>
          <url-pattern>/hello</url-pattern>
      </servlet-mapping>
  </web-app>
  ```

- Web.xml文件的作用是告诉tomcat我们想要使用哪一个servlet来处理对应的请求，tomcat通过该文件来找到对应的servlet来完成请求及响应的过程

- 将生成的class文件以及web.xml文件按照下面的目录结构放入webapps文件夹下

- ```
  webapps
    - MyFirstServlet
      - WEB-INF
        - classes
          - top
            - darkflow
              - MyFirstServlet.class
        - web.xml
  ```

- 重启tomcat服务并访问/MyFirstServlet/hello就能看到内容啦

##### JSP

- 从上面的代码中可以看出，直接使用servlet生成网页，不仅代码写起来麻烦，可维护性也不高，为了把HTML中的这些非逻辑的部分抽离出，我们引入了JSP技术

- JSP全称为JavaServer Pages，可以将其理解成一种高度抽象的servlet，在JSP运行期间实际上会被编译为servlet

- 使用jsp我们只需要在WEB-INF旁创建一个jsp文件并写入代码即可

- ```jsp
  <!--test.jsp-->
  <%@ page import="java.time.LocalDateTime" %>
  <html>
  <body>
  <h2>
  <%
  out.write(LocalDateTime.now().toString());
  %>
  </h2>
  </body>
  </html>
  ```

- 此时我们访问/MyFirstServlet/test.jsp即可

- 一些语法

  - `<% 代码片段 %>`等价于`<jsp:scriptlet> 代码片段 </jsp:scriptlet>`
  - `<%! 一些变量声明 %>`等价于`<jsp:declaration> 代码片段 </jsp:declaration>`

## Servlet

配置文件web.xml的一个示例，通过配置文件来解析URL

```xml
<!DOCTYPE web-app PUBLIC
        "-//Sun Microsystems, Inc.//DTD Web Application 2.3//EN"
        "http://java.sun.com/dtd/web-app_2_3.dtd" >

<web-app>
    <servlet>
        <servlet-name>downloadfile</servlet-name>
        <servlet-class>top.darkflow.Fileget</servlet-class>
    </servlet>
    <servlet-mapping>
        <servlet-name>downloadfile</servlet-name>
        <url-pattern>/down</url-pattern>
    </servlet-mapping>
</web-app>

```

文件下载

```java
public class Fileget extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String path=("/Users/jlan/IdeaProjects/javaweb-02-servlet/response/src/main/1.png");
        System.out.println("下载文件路径为："+path);
        String fileName=path.substring(path.lastIndexOf('/')+1);
        resp.setHeader("Content-Disposition","attachment:filename="+fileName);
        FileInputStream in=new FileInputStream(path);
        int len=0;
        byte[] buffer = new byte[1024];
        ServletOutputStream out=resp.getOutputStream();
        while((len=in.read(buffer))>0){
            out.write(buffer,0,len);
        }
        in.close();
        out.close();
    }
}
```

获取POST参数

```java
public class login extends HttpServlet {
    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        Enumeration<String> a=req.getParameterNames();
        while(a.hasMoreElements()){
            String paraName=a.nextElement();
            System.out.println(paraName+"="+req.getParameter(paraName));
        }
    }
}
```

#### JSP

JSP在编译的时候会被转换成一个Java类

```
//初始化
pubilc void _jspInit(){

}
//销毁
public void _jspDestory(){

}
//JSPService
public void _jspService()(HttpServletRequest request,HttpServletResponse response)
```

JSP作用

判断请求

内置的一些对象

```java
final javax.servlet.jsp.PageContext pageContext		//页面上下文
```

# Spring





























