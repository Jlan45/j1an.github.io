---
title: Windows内网域渗透2
abbrlink: a613eb0e
date: 2022-10-18 17:08:49
tags:
---

# BloodHound使用

安装略过，百度都有

首先需要去官方的Github项目中下载收集器，注意这个玩意需要.net 4.7以上的运行环境的，不然直接弹窗给你看

```powershell
#exe命令
SharpHound.exe -c all
#powershell命令
powershell -exec bypass -command "Import-Module ./SharpHound.ps1; Invoke-BloodHound -c all"
```

## 前置知识

### 关于身份认证方式

#### kerberos认证

- **简介**

  Kerberos协议是一个专注于验证通信双方身份的网络协议，不同于其他网络安全协议的保证整个通信过程的传输安全，kerberos侧重于通信前双方身份的认定工作，帮助客户端和服务端解决“证明我自己是我自己”的问题，从而使得通信两端能够完全信任对方身份，在一个不安全的网络中完成一次安全的身份认证继而进行安全的通信。

- **组成角色**

  **客户端（client）**：发送请求的一方

  **服务端（Server）**：接收请求的一方

  **密钥分发中心（Key Distribution Center，KDC）**，而密钥分发中心一般又分为两部分，分别是： 

  - **AS（Authentication Server）**：认证服务器，专门用来认证客户端的身份并发放客户用于访问TGS的TGT（票据授予票据） 
  - **TGS（Ticket Granting Ticket）**：票据授予服务器，用来发放整个认证过程以及客户端访问服务端时所需的服务授予票据（Ticket）

  在整个kerberos认证过程中，三个角色缺一不可

- **原理**

  为了方便我们理解，我们先假设这么一个场景，现在有ABC三人，A需要去找B完成一件事情，但是彼此并没有见过面，只知道对方的名字，那如果A直接去找B，A就没有办法向B直接证明自己就是A，所以现在他们找到了彼此都认识并且信任的C，让C给A一个凭证，由A交给B去找C来验证身份，这时A就能验证自己的身份了

  上面这个例子就很好的说明了kerberos认证的方式，A相当于客户端，B相当于服务端，C相当于KDC，KDC中包含一个叫做TGS（票据授予中心）的组件，我们便可以理解为他就是一个发放身份认证票据的服务中心，在KDC认证了（其实是KDC中的AS认证的）客户端的身份后，他会给客户端发放用于访问网络服务的服务授予票据（Ticket）。由于整个kerberos通信过程都采用对称加密的方式，密钥的获取也是从KDC中得到，所以KDC叫做密钥分发中心。 

- **流程**

  上面的原理搞明白了也就很容易知道流程了，不过我们还需要解决两个问题

  **问题1** KDC怎么知道你（客户端）就是真正的客户端？凭什么给你发放服务授予票据（Ticket）呢？

  **问题2** 服务端怎么知道你带来的服务授予票据（Ticket）就是一张真正的票据呢？

  所以说上面的原理只是一个简化后的模型，实际上的一次完整的kerberos认证总共需要三次通信

  1. 客户端首先需要来到KDC获得服务授予票据（Ticket）。由于客户端是第一次访问KDC，此时KDC也不确定该客户端的身份，所以**第一次通信的目的为KDC认证客户端身份，确认客户端是一个可靠且拥有访问KDC权限的客户端**
  2. 客户端会用自己的密钥将第二部分内容进行解密，分别获得时间戳，自己将要访问的TGS的信息，和用于与TGS通信时的密钥CT_SK。首先他会根据时间戳判断该时间戳与自己发送请求时的时间之间的差值是否大于5分钟，如果大于五分钟则认为该AS是伪造的，认证至此失败。如果时间戳合理，客户端便准备向TGS发起请求，
  3. 此时的客户端收到了来自KDC（TGS）的响应，并使用缓存在本地的CT_SK解密了第二部分内容（第一部分内容中的ST是由Server密码加密的，客户端无法解密），检查时间戳无误后取出其中的CS_SK准备向服务端发起最后的请求。

  了解到这些再看老庞的图

  ![image-20221010113610118](https://images-1306872001.cos.ap-nanjing.myqcloud.com/img/image-20221010113610118.png)

  ![image-20221010113606949](https://images-1306872001.cos.ap-nanjing.myqcloud.com/img/image-20221010113606949.png)

  ![62638be70e3e745194dca594](https://images-1306872001.cos.ap-nanjing.myqcloud.com/img/62638be70e3e745194dca594.png)

#### NTLM认证

本地密码哈希，没了

## BloodHound板块

1. Database Info（数据库信息），可查看当前数据库中的域用户，域计算机等统计信息

   ![](https://jlan-blog.oss-cn-beijing.aliyuncs.com/202210182041355.png)

2. Node Info（节点信息），单击某个节点时，可以看到对应节点的详细信息

   ![](https://jlan-blog.oss-cn-beijing.aliyuncs.com/202210182045362.png)

3. Analysis（分析查询）提供了一些预设好的查询语句

- **Find all Domain Admins**（查询所有域管理员）
- **Find Shortest Paths to Domain Admins**（找出域管理员的最短路径）





















































部分内容引用以下文章：

[详解kerberos认证原理](https://seevae.github.io/2020/09/12/详解kerberos认证流程/)
