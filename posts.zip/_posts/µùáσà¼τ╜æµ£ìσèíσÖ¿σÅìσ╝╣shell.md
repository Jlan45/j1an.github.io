---
title: 无公网服务器反弹shell
abbrlink: 23df454a
date: 2022-10-17 19:21:52
tags:
---

1. 用SakuraFrp（因为免费），https://www.natfrp.com/user/

2. 在**穿透—隧道**中开启一个新的隧道，本地端口可任意设定，本地端口即为稍后电脑要监听的端口

   ![](https://jlan-blog.oss-cn-beijing.aliyuncs.com/202210171924171.png)

3. 下载SakuraFrp的官方软件，运行，在个人中心中找到token并填入

   ![](https://jlan-blog.oss-cn-beijing.aliyuncs.com/202210171948612.png)

   ![](https://jlan-blog.oss-cn-beijing.aliyuncs.com/202210171949150.png)

   如图所示说明隧道已开启

4. 另起一个shell端口，监听之前设置过的端口

   `nc -lvp 设置的端口`

5. 用执行命令后提示的IP或域名来生成反弹shell命令

   ![](https://jlan-blog.oss-cn-beijing.aliyuncs.com/202210171952293.png)

6. 执行后成功弹shell

   ![](https://jlan-blog.oss-cn-beijing.aliyuncs.com/202210171952765.png)
