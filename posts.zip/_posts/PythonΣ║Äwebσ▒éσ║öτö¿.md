---
title: Python于web层应用
tags:
  - web
abbrlink: 4256
date: 2022-01-25 14:51:48
---

# Python于web层应用

## HTTP协议基础

### 协议分类

HTTP 1.0 80端口 单次一个链接

HTTP 1.1 80端口 多次可一个链接

HTTP协议不够安全，进而发展出了HTTPS协议

HTTPS 443端口 加密后数据传输

<!--more-->

### 请求方法

###### HTTP 1.0

GET POST HEAD

###### HTTP 1.1与HTTPS

OPTIONS PUT DELETE TRACE CONNECT PATCH

### URL格式

协议://主机名.域名/文件夹/文件?参数=值&参数=值

### HTTP请求头

User-Agent：浏览器版本信息

Accept-encoding：浏览器接受的编码

Referer：当前网页跳转来源

Cookie：顾名思义，~~好吃的饼干，~~Cookie信息

Location：跳转到哪里

Set-Cookie：设置Cookie信息

WWW-Authenticate：用于身份验证HTTP Basic等

### HTTP响应状态码

1XX：信息提示

2XX：成功

3XX：重定向

4XX：客户端错误

5XX：服务端错误

### 查看HTTP

使用浏览器审查进行查看

使用Burpsuite截断查看

## Python使用HTTP请求

###### GET请求

不带参数`requests.get(url)`

带参数`requests.get(url=url,params={"key1":"value1","key2":"value2"})`

返回的对象r.url获取url

###### POST请求

不带参数`requests.post(url)`

带参数`requests.post(url=url,data={"key1":"value1","key2":"value2"})`

###### 自定义请求头

headers={key1:value1,key2:value2}

requests.get(url=url,headers=headers)

###### 其他请求

requests.put(url,data)

requests.delete(url)

requests.head(url)

requests.options(url)

## Python处理HTTP响应

**获取相应状态码：**r.status_code

**获取响应文本：**r.content（获取到二进制内容）r.text（获取原始文本代码）

**获取相应头：**r.headers

**获取请求头：**r.reuqests.headers

**获取请求URL：**r.url

**获取Cookie：**r.cookies

## Python设置HTTP代理

**代理设置：**http和https:`proxies={'http':'http://代理服务器:代理端口','https':'https://代理服务器:代理端口'}`

**参数设置：**`proxies=proxies,verfiy=False`

## Python会话编程

通过Set-Cookie设置一个cookie值

使用`s=requesets.Session()`建立一个新的空会话

`r=s.get(url)`来在会话中发起个体请求

## Python制作目录扫描工具

###### 目录扫描原理

1、读取字典文件拼接URL

2、通过get请求访问URL

3、获取状态码判断目录是否存在

###### 字典文件读取

1、`with open("filename.txt","r") as f:`

2、读取方式：

- `f.readline()//读取一行`
- `f.readlines()//逐行读取到一个列表中`
- `f.read(字节数)//按字节读`
- `line.strip()//去除空行`

3、`f.close()`关闭文件流

4、sys库中的sys.argv[0]为当前python文件绝对路径，sys.argv[1]为传入第一个参数

5、User-Agent通过抓包先获取真实的User-Agent，再通过headers字典传入get请求

## IIS PUT漏洞

IIS中拓展工具WebDAV支持HTTP方法，也提供了一些其他功能强大的方法（Move），使得开启WebDAV可以直接上传任意文件

**探测方法：**通过HTTP中options方法可以探测出服务器支持的HTTP方法

**探测过程：**

- 确定目标主机
- 使用HTTP options方法探测
- 查看返回结果中是否存在MOVE PUT
- 查看响应头中的PUBLIC属性

## 探测服务器信息

相应头中的Server：服务器中间件属性

X-Powered-By：服务器脚本技术

## Python制作漏洞检测工具

首先了解漏洞产生原理，根据漏洞原理写出对应的POC代码来验证漏洞是否存在

## 构建站点地图

测试Web App的首要任务就是获取站点完整的目录和文件

###### 技术种类：建议使用两种方式同时进行

1、通过基于字典的目录文件扫描

2、通过基于网络爬虫的技术（可通过requests库构建，但是很复杂，有scrapy库可用于构建爬虫）

3、通过Burpsuite构建网站地图
